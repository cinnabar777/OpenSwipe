// This is the last complex SwipeGestureEngine.java before we stripped it down to minimal DTW.
// It includes sandbox, DTW, settings, learning hooks, and the fallback latch.
// Use it as a reference for what we built.

package helium314.keyboard.latin.gesture;

import android.content.Context;
import android.graphics.Rect;
import android.provider.UserDictionary;
import android.util.Log;
import helium314.keyboard.keyboard.Key;
import helium314.keyboard.keyboard.Keyboard;
import helium314.keyboard.latin.SuggestedWords.SuggestedWordInfo;
import helium314.keyboard.latin.common.InputPointers;
import helium314.keyboard.latin.dictionary.Dictionary;
import helium314.keyboard.latin.utils.SuggestionResults;
import helium314.keyboard.latin.settings.GestureSettings;

import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class SwipeGestureEngine {

    private static final int N_PTS = 16;
    private static final float FREQ_WEIGHT = 0.15f;

    // Settings‑driven constants (reloaded from default preferences via Context)
    private static float sProximityRadius = GestureSettings.DEFAULT_PROXIMITY_RADIUS;
    private static float sAlignmentToleranceSq = GestureSettings.DEFAULT_ALIGNMENT_TOLERANCE;
    private static float sSandboxThreshold = GestureSettings.DEFAULT_SANDBOX_THRESHOLD;
    private static boolean sUseSandbox = GestureSettings.DEFAULT_USE_SANDBOX;
    private static boolean sUseDtw = GestureSettings.DEFAULT_USE_DTW;
    private static boolean sRestrictToSandbox = GestureSettings.DEFAULT_RESTRICT_TO_SANDBOX;
    private static boolean sNodeFilterEnabled = GestureSettings.DEFAULT_NODE_FILTER_ENABLED;
    private static float sNodeMatchRatio = GestureSettings.DEFAULT_NODE_MATCH_RATIO;
    private static boolean sNodeFilterBeforeScoring = GestureSettings.DEFAULT_NODE_FILTER_BEFORE_SCORING;
    private static float sNodeAngleThreshold = GestureSettings.DEFAULT_NODE_ANGLE_THRESHOLD;
    private static boolean sLearnTappedKnown = GestureSettings.DEFAULT_LEARN_TAPPED_KNOWN;
    private static boolean sLearnTappedUnknown = GestureSettings.DEFAULT_LEARN_TAPPED_UNKNOWN;
    private static boolean sSyncUserDict = GestureSettings.DEFAULT_SYNC_USER_DICT;
    private static int sPathsPerWord = GestureSettings.DEFAULT_PATHS_PER_WORD;
    private static float sToleranceBoost = GestureSettings.DEFAULT_TOLERANCE_BOOST;
    private static int sOffsetCopies = GestureSettings.DEFAULT_OFFSET_COPIES;
    private static int sDwellTimeMs = GestureSettings.DEFAULT_DWELL_TIME;
    private static float sWiggleSensitivity = GestureSettings.DEFAULT_WIGGLE_SENSITIVITY;
    private static float sLoopSensitivity = GestureSettings.DEFAULT_LOOP_SENSITIVITY;
    private static boolean sShowEngineId = GestureSettings.DEFAULT_SHOW_ENGINE_ID;

    private static final int DTW_BAND = 2;
    private static final int EARLY_LIFT_MIN_DELTA = 3;
    private static final float TRIGRAM_WEIGHT = 0.12f;

    private static final String TAG = "GestureEngine";

    private static final ConcurrentHashMap<String, Integer> sUserBoost = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, float[]> sUserPaths = new ConcurrentHashMap<>();
    private static final int USER_BOOST_MAX = 50;
    private static final float[] sUserBoostCache = new float[USER_BOOST_MAX + 1];
    static {
        for (int i = 0; i <= USER_BOOST_MAX; i++) {
            sUserBoostCache[i] = (float) Math.log(i + 1) * 0.08f;
        }
    }

    private static GestureDictionary sGestureDict = null;
    private static File sDictFile = null;

    private static final List<GestureEvent> sHoldingPen = new ArrayList<>();
    private static boolean mIncognito = false;

    private static String sPrevWord1 = null;
    private static String sPrevWord2 = null;

    private static Context sAppContext = null;

    // Cached indices (disk + RAM)
    private static int sLastFingerprint = -1;
    private static GestureIndex sFullIndex = null;
    private static GestureIndex sSandboxIndex = null;

    // Fallback latch state
    private static boolean sUseFallback = false;
    private static int sFallbackFrames = 0;
    private static final int FALLBACK_GRACE_FRAMES = 3;

    private static float[] sLastInputVec = null;
    private static float sLastInputLength = 0f;
    private static float[][] sLastCharToPos = null;
    private static Keyboard sLastKeyboard = null;
    private static InputPointers sLastPointers = null;
    private static String sLastNodeSignature = null;

    public static void initialize(Context context) {
        if (sAppContext != null) return;
        sAppContext = context.getApplicationContext();
        sDictFile = new File(sAppContext.getFilesDir(), "gesture_dict.bin");
        sGestureDict = new GestureDictionary();
        sGestureDict.load(sDictFile);
        reloadSettings();
    }

    /** Reads all settings from the default shared preferences (same file the settings UI uses). */
    public static void reloadSettings() {
        if (sAppContext == null) return;
        sUseSandbox = GestureSettings.getUseSandbox(sAppContext);
        sUseDtw = GestureSettings.getUseDtw(sAppContext);
        sRestrictToSandbox = GestureSettings.getRestrictToSandbox(sAppContext);
        Log.i(TAG, "reloadSettings: restrictToSandbox=" + sRestrictToSandbox);
        sSandboxThreshold = GestureSettings.getSandboxThreshold(sAppContext);
        sProximityRadius = GestureSettings.getProximityRadius(sAppContext);
        sAlignmentToleranceSq = GestureSettings.getAlignmentTolerance(sAppContext);
        sNodeFilterEnabled = GestureSettings.getNodeFilterEnabled(sAppContext);
        sNodeMatchRatio = GestureSettings.getNodeMatchRatio(sAppContext);
        sNodeFilterBeforeScoring = GestureSettings.getNodeFilterBeforeScoring(sAppContext);
        sNodeAngleThreshold = GestureSettings.getNodeAngleThreshold(sAppContext);
        sLearnTappedKnown = GestureSettings.getLearnTappedKnown(sAppContext);
        sLearnTappedUnknown = GestureSettings.getLearnTappedUnknown(sAppContext);
        sSyncUserDict = GestureSettings.getSyncUserDict(sAppContext);
        sPathsPerWord = GestureSettings.getPathsPerWord(sAppContext);
        sToleranceBoost = GestureSettings.getToleranceBoost(sAppContext);
        sOffsetCopies = GestureSettings.getOffsetCopies(sAppContext);
        sDwellTimeMs = GestureSettings.getDwellTime(sAppContext);
        sWiggleSensitivity = GestureSettings.getWiggleSensitivity(sAppContext);
        sLoopSensitivity = GestureSettings.getLoopSensitivity(sAppContext);
        sShowEngineId = GestureSettings.getShowEngineId(sAppContext);
    }

    public static void syncUserHistory(helium314.keyboard.latin.DictionaryFacilitator facilitator) {
        if (sGestureDict == null || sFullIndex == null) return;
        facilitator.forEachUserHistoryWord((word, freq) -> {
            if (word == null || word.length() < 2) return;
            String lk = word.toLowerCase(Locale.ROOT);
            if (!sGestureDict.contains(lk) && !facilitator.isBlacklisted(lk)) {
                boolean inDict = facilitator.isInMainDictionary(lk);
                if ((inDict && sLearnTappedKnown) || (!inDict && sLearnTappedUnknown)) {
                    float[] path = wordPath(lk, sFullIndex.charToPos);
                    sGestureDict.addOrUpdateWord(lk, path, 1);
                    addWordToSandbox(lk, path, 1);
                }
            }
        });
        sGestureDict.save(sDictFile);
    }

    public static void onWordTapped(String word, helium314.keyboard.latin.DictionaryFacilitator facilitator) {
        if (sGestureDict == null || sFullIndex == null) return;
        String lk = word.toLowerCase(Locale.ROOT);
        if (sGestureDict.contains(lk)) return;
        boolean inDict = facilitator.isInMainDictionary(lk);
        if ((inDict && !sLearnTappedKnown) || (!inDict && !sLearnTappedUnknown)) return;
        float[] path = wordPath(lk, sFullIndex.charToPos);
        sGestureDict.addOrUpdateWord(lk, path, 1);
        addWordToSandbox(lk, path, 1);
    }

    public static void setPredictionContext(String prevWord1, String prevWord2) {
        sPrevWord1 = prevWord1;
        sPrevWord2 = prevWord2;
    }

    public static void setIncognitoMode(boolean incognito) {
        mIncognito = incognito;
    }

    public static void markLastGestureBackspaced() {
        if (mIncognito) return;
        synchronized (sHoldingPen) {
            for (int i = sHoldingPen.size() - 1; i >= 0; i--) {
                GestureEvent ev = sHoldingPen.get(i);
                if (!ev.backspaced) {
                    ev.backspaced = true;
                    break;
                }
            }
        }
    }

    public static List<String> getGestureCandidates(String word) {
        synchronized (sHoldingPen) {
            for (int i = sHoldingPen.size() - 1; i >= 0; i--) {
                GestureEvent ev = sHoldingPen.get(i);
                if (ev.word.equalsIgnoreCase(word) && ev.candidates != null) {
                    List<String> result = new ArrayList<>();
                    for (IndexEntry e : ev.candidates) result.add(e.word);
                    return result;
                }
            }
        }
        return Collections.emptyList();
    }

    public static void onSuggestionPicked(String originalWord, String newWord) {
        if (mIncognito || originalWord == null || newWord == null) return;
        String origLower = originalWord.toLowerCase(Locale.ROOT);
        String newLower = newWord.toLowerCase(Locale.ROOT);
        synchronized (sHoldingPen) {
            for (int i = sHoldingPen.size() - 1; i >= 0; i--) {
                GestureEvent ev = sHoldingPen.get(i);
                if (ev.word.equals(origLower) && !ev.backspaced) {
                    ev.corrected = true;
                    ev.correctedWord = newLower;
                    GestureEvent newEvent = new GestureEvent();
                    newEvent.word = newLower;
                    newEvent.path = (ev.path != null) ? ev.path.clone() : null;
                    newEvent.candidates = ev.candidates;
                    sHoldingPen.add(newEvent);
                    break;
                }
            }
        }
    }

    public static void recordAccepted(String word, InputPointers pointers, Keyboard keyboard, GestureIndex activeIndex) {
        if (word == null || word.isEmpty()) return;
        String key = word.toLowerCase(Locale.ROOT);
        sUserBoost.merge(key, 1, (a, b) -> Math.min(a + b, USER_BOOST_MAX));

        float[] inputVec = null;
        if (pointers != null && pointers.getPointerSize() >= 2 && keyboard != null) {
            int n = pointers.getPointerSize();
            int[] xs = pointers.getXCoordinates();
            int[] ys = pointers.getYCoordinates();
            float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;
            float[] rawFlat = new float[n * 2];
            for (int i = 0; i < n; i++) {
                rawFlat[2 * i]     = xs[i] / kw;
                rawFlat[2 * i + 1] = ys[i] / kh;
            }
            inputVec = resampleFlat(rawFlat, n, N_PTS);
            sUserPaths.put(key, inputVec);

            if (activeIndex != null && !key.isEmpty()) {
                char first = key.charAt(0);
                List<IndexEntry> list = activeIndex.byFirst.get(first);
                if (list != null) {
                    for (IndexEntry entry : list) {
                        if (getLowerCase(entry.word).equals(key)) {
                            float[] path = new float[N_PTS * 2];
                            entry.unpackPath(path);
                            for (int i = 0; i < N_PTS * 2; i++) {
                                path[i] = path[i] * 0.3f + inputVec[i] * 0.7f;
                            }
                            entry.updatePath(path);
                            break;
                        }
                    }
                }
            }
        }

        if (!mIncognito && key.length() >= 2 && !containsSpecialChars(key)) {
            GestureEvent event = new GestureEvent();
            event.word = key;
            event.path = (inputVec != null) ? inputVec.clone() : null;
            if (sSandboxIndex != null) {
                List<IndexEntry> cands = sSandboxIndex.byFirst.get(key.charAt(0));
                if (cands != null) event.candidates = new ArrayList<>(cands);
            }
            synchronized (sHoldingPen) {
                sHoldingPen.add(event);
            }
        }
    }

    private static boolean containsSpecialChars(String word) {
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (c == '\'' || c == '-' || c == '’') continue;
            if (!Character.isLetter(c)) return true;
        }
        return false;
    }

    public static void onKeyboardClose() {
        if (mIncognito) return;
        List<GestureEvent> eventsToProcess;
        synchronized (sHoldingPen) {
            eventsToProcess = new ArrayList<>(sHoldingPen);
            sHoldingPen.clear();
        }
        if (sGestureDict == null) return;

        String prev1 = sPrevWord1;
        String prev2 = sPrevWord2;

        for (GestureEvent ev : eventsToProcess) {
            if (ev.backspaced) continue;

            String acceptedWord = null;
            if (ev.corrected) {
                if (ev.correctedWord != null && ev.correctedWord.length() >= 2) {
                    sGestureDict.addOrUpdateWord(ev.correctedWord, ev.path, 5);
                    acceptedWord = ev.correctedWord;
                    if (sSyncUserDict) maybeAddToUserDictionary(ev.correctedWord);
                }
                if (ev.word != null) {
                    sGestureDict.addOrUpdateWord(ev.word, null, -1);
                }
            } else {
                if (ev.word != null && ev.word.length() >= 2) {
                    sGestureDict.addOrUpdateWord(ev.word, ev.path, 1);
                    acceptedWord = ev.word;
                }
            }

            if (acceptedWord != null && prev1 != null && prev2 != null) {
                sGestureDict.updateTrigram(prev1, prev2, acceptedWord);
                prev1 = prev2;
                prev2 = acceptedWord;
            }
        }
        sGestureDict.save(sDictFile);
    }

    private static void maybeAddToUserDictionary(String word) {
        if (sAppContext == null) return;
        try { UserDictionary.Words.addWord(sAppContext, word, 250, null, Locale.getDefault()); } catch (Exception ignored) {}
    }

    // ── Index building with disk caching ────────────────────────────────────

    private static File indexCacheFile(int fingerprint) {
        return new File(sAppContext.getFilesDir(), "gesture_index_" + fingerprint + ".bin");
    }

    private static String getLowerCase(String s) {
        int len = s.length();
        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if (c >= 'A' && c <= 'Z') return s.toLowerCase(Locale.ROOT);
        }
        return s;
    }

    private static String canonicalNodeSeq(String word) {
        StringBuilder sb = new StringBuilder();
        char prev = 0;
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (c >= 'a' && c <= 'z' && c != prev) { sb.append(c); prev = c; }
        }
        return sb.toString();
    }

    private static long trigramHash(String w1, String w2) { return ((long)w1.hashCode() * 31 + (long)w2.hashCode()); }

    private static long pack8Bytes(float[] pts, int start) {
        long value = 0;
        for (int i = 0; i < 8; i++) {
            float f = pts[start + i];
            if (f < 0f) f = 0f; else if (f > 1f) f = 1f;
            int b = Math.round(f * 255f) & 0xFF;
            value |= ((long) b) << (i * 8);
        }
        return value;
    }

    private static void unpack8Bytes(long value, float[] out, int start) {
        for (int i = 0; i < 8; i++) {
            int b = (int) ((value >>> (i * 8)) & 0xFF);
            out[start + i] = b / 255f;
        }
    }

    public static class IndexEntry {
        public final String word;
        public final int frequency;
        public float pathLen;
        public final float freqBonus;
        private long path0, path1, path2, path3;
        public IndexEntry(String word, float[] path, int frequency) {
            this.word = word;
            this.frequency = frequency;
            this.freqBonus = (frequency > 0) ? (float)(Math.log(frequency + 1) * FREQ_WEIGHT) : 0f;
            String lk = getLowerCase(word);
            float[] blended = path;
            float[] userPath = sUserPaths.get(lk);
            if (userPath != null && userPath.length == N_PTS * 2) {
                blended = new float[N_PTS * 2];
                for (int i = 0; i < N_PTS * 2; i++) {
                    blended[i] = path[i] * 0.3f + userPath[i] * 0.7f;
                }
            }
            updatePath(blended);
        }
        public void updatePath(float[] newPath) {
            this.path0 = pack8Bytes(newPath, 0);
            this.path1 = pack8Bytes(newPath, 8);
            this.path2 = pack8Bytes(newPath, 16);
            this.path3 = pack8Bytes(newPath, 24);
            this.pathLen = pathLength(newPath);
        }
        public void unpackPath(float[] out) {
            unpack8Bytes(path0, out, 0);
            unpack8Bytes(path1, out, 8);
            unpack8Bytes(path2, out, 16);
            unpack8Bytes(path3, out, 24);
        }
    }

    public static class TrieNode {
        Map<Character, TrieNode> children = new HashMap<>();
        List<IndexEntry> entries;
        void insert(String seq, int pos, IndexEntry entry) {
            if (pos == seq.length()) {
                if (entries == null) entries = new ArrayList<>();
                entries.add(entry);
                return;
            }
            char c = seq.charAt(pos);
            TrieNode child = children.get(c);
            if (child == null) {
                child = new TrieNode();
                children.put(c, child);
            }
            child.insert(seq, pos + 1, entry);
        }
        List<IndexEntry> getCandidates(String prefix) {
            TrieNode node = this;
            for (int i = 0; i < prefix.length(); i++) {
                char c = prefix.charAt(i);
                node = node.children.get(c);
                if (node == null) return null;
            }
            return node.entries;
        }
        void collectAll(List<IndexEntry> out) {
            if (entries != null) out.addAll(entries);
            for (TrieNode child : children.values()) child.collectAll(out);
        }
    }

    public static class GestureIndex {
        public final Map<Character, List<IndexEntry>> byFirst;
        public final float[][] charToPos;
        public final GestureIndex sandboxIndex;
        public final TrieNode sandboxTrie;
        GestureIndex(Map<Character, List<IndexEntry>> byFirst, float[][] charToPos,
                     GestureIndex sandboxIndex, TrieNode sandboxTrie) {
            this.byFirst = byFirst; this.charToPos = charToPos;
            this.sandboxIndex = sandboxIndex; this.sandboxTrie = sandboxTrie;
        }
    }

    public static GestureIndex buildIndex(helium314.keyboard.latin.DictionaryFacilitator facilitator, Keyboard keyboard) {
        int fingerprint = layoutFingerprint(keyboard);
        if (fingerprint == sLastFingerprint && sFullIndex != null) return sFullIndex;

        File cacheFile = indexCacheFile(fingerprint);
        // Only load disk cache if we have gesture dictionary entries (not fresh install)
        if (cacheFile.exists() && sGestureDict != null && !sGestureDict.getEntries().isEmpty()) {
            GestureIndex loaded = loadIndexFromDisk(cacheFile, keyboard);
            if (loaded != null) {
                sLastFingerprint = fingerprint;
                sFullIndex = loaded;
                sSandboxIndex = loaded.sandboxIndex;
                Log.i(TAG, "Loaded index from disk cache");
                return sFullIndex;
            }
        }

        // Build from scratch
        float[][] charToPos = buildCharToPos(keyboard);
        Map<Character, List<IndexEntry>> byFirst = new HashMap<>();
        facilitator.forEachMainDictionaryWord((raw, freqVal) -> {
            if (raw == null) return;
            if (facilitator.isBlacklisted(raw)) return;
            int freq = freqVal != null ? freqVal : 0;
            String lk = getLowerCase(raw);
            Integer boost = sUserBoost.get(lk);
            if (boost != null) freq = Math.min(freq + boost * 5, 255);
            if (freq < 3) return;
            if (lk.isEmpty()) return;
            char first = lk.charAt(0);
            if (first < 'a' || first > 'z') return;
            float[] path = wordPath(lk, charToPos);
            byFirst.computeIfAbsent(first, k -> new ArrayList<>()).add(new IndexEntry(raw, path, freq));
        });
        for (List<IndexEntry> list : byFirst.values()) list.sort((a,b) -> Integer.compare(b.frequency, a.frequency));

        // Sandbox: gesture dict + user history
        Map<Character, List<IndexEntry>> sandboxByFirst = new HashMap<>();
        TrieNode sandboxTrie = new TrieNode();
        Set<String> seen = new HashSet<>();

        if (sGestureDict != null) {
            for (WordEntry we : sGestureDict.getEntries()) {
                String lower = we.word;
                if (seen.contains(lower)) continue;
                seen.add(lower);
                float[] path = we.path();
                if (path == null) path = wordPath(lower, charToPos);
                addToSandbox(sandboxByFirst, lower, path, we.frequency, charToPos, sandboxTrie);
            }
        }

        facilitator.forEachUserHistoryWord((word, freq) -> {
            if (word == null || word.length() < 2) return;
            String lower = getLowerCase(word);
            if (seen.contains(lower) || facilitator.isBlacklisted(lower)) return;
            seen.add(lower);
            float[] path = wordPath(lower, charToPos);
            addToSandbox(sandboxByFirst, lower, path, freq != null ? freq : 1, charToPos, sandboxTrie);
        });

        GestureIndex sandbox = null;
        if (!sandboxByFirst.isEmpty()) sandbox = new GestureIndex(sandboxByFirst, charToPos, null, null);

        sFullIndex = new GestureIndex(byFirst, charToPos, sandbox, sandboxTrie);
        sSandboxIndex = sandbox;
        sLastFingerprint = fingerprint;

        saveIndexToDisk(cacheFile, sFullIndex);
        if (sGestureDict != null) sGestureDict.save(sDictFile);
        Log.i(TAG, "buildIndex: sandbox size = " + seen.size());
        return sFullIndex;
    }

    private static void addWordToSandbox(String word, float[] path, int freq) {
        if (sSandboxIndex == null) return;
        char first = word.charAt(0);
        if (first < 'a' || first > 'z') return;
        if (freq < 1) freq = 1;
        IndexEntry entry = new IndexEntry(word, path, freq);
        sSandboxIndex.byFirst.computeIfAbsent(first, k -> new ArrayList<>()).add(entry);
        if (sFullIndex != null && sFullIndex.sandboxTrie != null) {
            sFullIndex.sandboxTrie.insert(canonicalNodeSeq(word), 0, entry);
        }
    }

    private static void addToSandbox(Map<Character, List<IndexEntry>> map, String word, float[] path, int freq,
                                     float[][] charToPos, TrieNode trie) {
        char first = word.charAt(0);
        if (first < 'a' || first > 'z') return;
        if (freq < 1) freq = 1;
        IndexEntry entry = new IndexEntry(word, path, freq);
        map.computeIfAbsent(first, k -> new ArrayList<>()).add(entry);
        trie.insert(canonicalNodeSeq(word), 0, entry);
    }

    private static void saveIndexToDisk(File file, GestureIndex index) {
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeInt(1);
            out.writeInt(26);
            for (int i = 0; i < 26; i++) { out.writeFloat(index.charToPos[i][0]); out.writeFloat(index.charToPos[i][1]); }
            GestureIndex sand = index.sandboxIndex;
            if (sand == null) out.writeInt(0);
            else {
                out.writeInt(sand.byFirst.size());
                for (Map.Entry<Character, List<IndexEntry>> e : sand.byFirst.entrySet()) {
                    out.writeChar(e.getKey());
                    List<IndexEntry> list = e.getValue();
                    out.writeInt(list.size());
                    for (IndexEntry ie : list) {
                        out.writeUTF(ie.word);
                        out.writeInt(ie.frequency);
                        float[] p = new float[N_PTS*2];
                        ie.unpackPath(p);
                        for (float v : p) out.writeFloat(v);
                    }
                }
            }
        } catch (IOException e) { Log.e(TAG, "Error saving index cache", e); }
    }

    private static GestureIndex loadIndexFromDisk(File file, Keyboard keyboard) {
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            int version = in.readInt();
            if (version != 1) return null;
            float[][] charToPos = new float[26][2];
            int posCount = in.readInt();
            for (int i = 0; i < posCount && i < 26; i++) {
                charToPos[i][0] = in.readFloat(); charToPos[i][1] = in.readFloat();
            }
            Map<Character, List<IndexEntry>> sandboxByFirst = new HashMap<>();
            TrieNode sandboxTrie = new TrieNode();
            int sandSize = in.readInt();
            for (int i = 0; i < sandSize; i++) {
                char first = in.readChar();
                int listSize = in.readInt();
                List<IndexEntry> list = new ArrayList<>();
                for (int j = 0; j < listSize; j++) {
                    String word = in.readUTF();
                    int freq = in.readInt();
                    float[] path = new float[N_PTS*2];
                    for (int k = 0; k < N_PTS*2; k++) path[k] = in.readFloat();
                    IndexEntry entry = new IndexEntry(word, path, freq);
                    list.add(entry);
                    sandboxTrie.insert(canonicalNodeSeq(word), 0, entry);
                }
                sandboxByFirst.put(first, list);
            }
            GestureIndex sandbox = sandboxByFirst.isEmpty() ? null : new GestureIndex(sandboxByFirst, charToPos, null, null);
            GestureIndex full = new GestureIndex(new HashMap<>(), charToPos, sandbox, sandboxTrie);
            sSandboxIndex = sandbox;
            return full;
        } catch (IOException e) { Log.e(TAG, "Error loading index cache", e); return null; }
    }

    public static int layoutFingerprint(Keyboard keyboard) {
        return Arrays.deepHashCode(buildCharToPos(keyboard));
    }

    // ── Matching API ─────────────────────────────────────────────────────────

    private static boolean isAsciiLetter(int code) { return (code >= 'a' && code <= 'z') || (code >= 'A' && code <= 'Z'); }

    private static List<Character> nearestLettersFromMap(float nx, float ny, float[][] charToPos) {
        float minDist = Float.MAX_VALUE;
        float[] dists = new float[26];
        for (int i = 0; i < 26; i++) {
            float cx = charToPos[i][0], cy = charToPos[i][1];
            if (cx == 0f && cy == 0f) { dists[i] = Float.MAX_VALUE; continue; }
            float d = (nx - cx) * (nx - cx) + (ny - cy) * (ny - cy);
            dists[i] = d; if (d < minDist) minDist = d;
        }
        List<Character> results = new ArrayList<>(4);
        float threshold = minDist + sProximityRadius;
        for (int i = 0; i < 26; i++) if (dists[i] <= threshold) results.add((char)('a'+i));
        return results;
    }

    public static List<Character> nearestLetters(int x, int y, Keyboard keyboard) {
        float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;
        return nearestLettersFromMap(x / kw, y / kh, buildCharToPos(keyboard));
    }

    // ── Node extraction ──────────────────────────────────────────────────────

    private static String extractNodeSignature(float[] rawFlat, int numPoints, float[][] charToPos) {
        if (numPoints < 2) return "";
        StringBuilder sb = new StringBuilder();
        float[] vecX = new float[numPoints - 1];
        float[] vecY = new float[numPoints - 1];
        for (int i = 0; i < numPoints - 1; i++) {
            vecX[i] = rawFlat[2 * (i + 1)] - rawFlat[2 * i];
            vecY[i] = rawFlat[2 * (i + 1) + 1] - rawFlat[2 * i + 1];
        }

        char lastKey = 0;
        char startKey = getNearestKey(rawFlat[0], rawFlat[1], charToPos);
        if (startKey >= 'a' && startKey <= 'z') {
            sb.append(startKey);
            lastKey = startKey;
        }

        for (int i = 1; i < numPoints - 2; i++) {
            float v1x = vecX[i - 1];
            float v1y = vecY[i - 1];
            float v2x = vecX[i];
            float v2y = vecY[i];

            float len1Sq = v1x * v1x + v1y * v1y;
            float len2Sq = v2x * v2x + v2y * v2y;
            if (len1Sq == 0 || len2Sq == 0) continue;

            float dot = v1x * v2x + v1y * v2y;
            float cross = v1x * v2y - v1y * v2x;
            float angle = (float) Math.toDegrees(Math.atan2(Math.abs(cross), dot));
            if (angle >= sNodeAngleThreshold) {
                char key = getNearestKey(rawFlat[2 * i], rawFlat[2 * i + 1], charToPos);
                if (key >= 'a' && key <= 'z' && key != lastKey) {
                    sb.append(key);
                    lastKey = key;
                }
            }
        }

        char endKey = getNearestKey(rawFlat[2 * (numPoints - 1)], rawFlat[2 * (numPoints - 1) + 1], charToPos);
        if (endKey >= 'a' && endKey <= 'z' && endKey != lastKey) {
            sb.append(endKey);
        }

        return sb.toString();
    }

    private static char getNearestKey(float x, float y, float[][] charToPos) {
        float minDist = Float.MAX_VALUE;
        char best = 0;
        for (int i = 0; i < 26; i++) {
            float cx = charToPos[i][0], cy = charToPos[i][1];
            if (cx == 0f && cy == 0f) continue;
            float d = (x - cx) * (x - cx) + (y - cy) * (y - cy);
            if (d < minDist) {
                minDist = d;
                best = (char) ('a' + i);
            }
        }
        return best;
    }

    // ── LCS filter ───────────────────────────────────────────────────────────

    private static int longestCommonSubsequence(String a, String b) {
        int m = a.length(), n = b.length();
        int[] dp = new int[n + 1];
        for (int i = 1; i <= m; i++) {
            int prev = 0;
            for (int j = 1; j <= n; j++) {
                int temp = dp[j];
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    dp[j] = prev + 1;
                } else {
                    dp[j] = Math.max(dp[j], dp[j - 1]);
                }
                prev = temp;
            }
        }
        return dp[n];
    }

    private static List<IndexEntry> lcsFilter(List<IndexEntry> candidates, String nodeSignature) {
        if (!sNodeFilterEnabled || nodeSignature.isEmpty()) return candidates;
        List<IndexEntry> filtered = new ArrayList<>();
        int minMatch = Math.max(1, (int) Math.ceil(sNodeMatchRatio * nodeSignature.length()));
        for (IndexEntry e : candidates) {
            String wordSeq = canonicalNodeSeq(getLowerCase(e.word));
            if (longestCommonSubsequence(nodeSignature, wordSeq) >= minMatch) {
                filtered.add(e);
            }
        }
        return filtered.isEmpty() ? candidates : filtered;
    }

    // ── Gesture hints ────────────────────────────────────────────────────────

    private static Character detectDoubleLetterLoop(InputPointers pointers, float[][] charToPos, Keyboard keyboard) {
        int n = pointers.getPointerSize();
        if (n < 4) return null;
        int[] xs = pointers.getXCoordinates();
        int[] ys = pointers.getYCoordinates();
        float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;

        for (int i = 0; i < n - 2; i++) {
            for (int j = i + 2; j < n - 1; j++) {
                float x1 = xs[i], y1 = ys[i];
                float x2 = xs[i+1], y2 = ys[i+1];
                float x3 = xs[j], y3 = ys[j];
                float x4 = xs[j+1], y4 = ys[j+1];

                float d = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
                if (Math.abs(d) < 1e-6f) continue;

                float t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / d;
                float u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / d;

                if (t >= 0f && t <= 1f && u >= 0f && u <= 1f) {
                    float ix = x1 + t * (x2 - x1);
                    float iy = y1 + t * (y2 - y1);
                    float nx = ix / kw;
                    float ny = iy / kh;
                    float neighborFactor = 1.5f - sLoopSensitivity;
                    List<Character> nearest = nearestLettersFromMap(nx, ny, charToPos);
                    if (!nearest.isEmpty()) return nearest.get(0);
                }
            }
        }
        return null;
    }

    private static Character detectWiggledLetter(InputPointers pointers, float[][] charToPos, Keyboard keyboard) {
        int n = pointers.getPointerSize();
        if (n < 5) return null;
        int[] xs = pointers.getXCoordinates();
        int[] ys = pointers.getYCoordinates();
        float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;

        for (int i = 1; i < n - 2; i++) {
            float v1x = xs[i] - xs[i-1];
            float v1y = ys[i] - ys[i-1];
            float v2x = xs[i+1] - xs[i];
            float v2y = ys[i+1] - ys[i];

            float dot = v1x * v2x + v1y * v2y;
            float len1Sq = v1x * v1x + v1y * v1y;
            float len2Sq = v2x * v2x + v2y * v2y;

            float thresholdDot = -0.5f + (1.0f - sWiggleSensitivity) * 0.4f;
            float chordRatioThreshold = 0.3f + (1.0f - sWiggleSensitivity) * 0.4f;

            if (dot < thresholdDot * Math.sqrt(len1Sq * len2Sq)) {
                float chordX = xs[i+1] - xs[i-1];
                float chordY = ys[i+1] - ys[i-1];
                float chordSq = chordX * chordX + chordY * chordY;
                float totalLen = (float)(Math.sqrt(len1Sq) + Math.sqrt(len2Sq));
                if (chordSq < totalLen * totalLen * chordRatioThreshold) {
                    float midX = xs[i];
                    float midY = ys[i];
                    List<Character> nearest = nearestLettersFromMap(midX / kw, midY / kh, charToPos);
                    if (!nearest.isEmpty()) return nearest.get(0);
                }
            }
        }
        return null;
    }

    private static final float DWELL_RADIUS_SQ = 0.01f;
    private static final float DWELL_SPEED_THRESHOLD = 0.5f;

    private static Character detectDwelledLetter(InputPointers pointers, Keyboard keyboard, float[][] charToPos) {
        int n = pointers.getPointerSize();
        if (n < 3) return null;
        int[] xs = pointers.getXCoordinates();
        int[] ys = pointers.getYCoordinates();
        int[] times = pointers.getTimes();
        float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;

        boolean useEstimates = (times == null);
        char currentKey = 0;
        int dwellStartIdx = 0;

        for (int i = 0; i < n; i++) {
            float nx = xs[i] / kw;
            float ny = ys[i] / kh;
            char key = getNearestKey(nx, ny, charToPos);
            if (key < 'a' || key > 'z') continue;

            float dx = charToPos[key - 'a'][0] - nx;
            float dy = charToPos[key - 'a'][1] - ny;
            float distSq = dx * dx + dy * dy;

            if (key == currentKey && distSq <= DWELL_RADIUS_SQ) {
                int elapsed;
                if (useEstimates) {
                    elapsed = (i - dwellStartIdx) * 10;
                } else {
                    elapsed = times[i] - times[dwellStartIdx];
                }
                float moveDist = 0;
                if (i > dwellStartIdx) {
                    float sx = xs[dwellStartIdx] / kw;
                    float sy = ys[dwellStartIdx] / kh;
                    float ex = nx;
                    float ey = ny;
                    moveDist = (float) Math.sqrt((ex - sx) * (ex - sx) + (ey - sy) * (ey - sy));
                }
                float speed = (elapsed > 0) ? moveDist / elapsed : 0;
                if (elapsed >= sDwellTimeMs && speed < DWELL_SPEED_THRESHOLD) {
                    return currentKey;
                }
            } else {
                currentKey = key;
                dwellStartIdx = i;
            }
        }
        return null;
    }

    // ── Sequence match ───────────────────────────────────────────────────────

    public static boolean isSequenceMatch(String word, float[] path, float[][] charToPos) {
        int n = path.length / 2;
        int segmentIdx = 0;
        float prevT = -0.01f;
        char lastChar = 0;
        float[] outT = new float[1];
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (c < 'a' || c > 'z') continue;
            if (c == lastChar) continue;
            float[] target = charToPos[c - 'a'];
            if (target[0] == 0f && target[1] == 0f) continue;
            boolean found = false;
            while (segmentIdx < n - 1) {
                float distSq = sqDistanceToSegment(target[0], target[1],
                        path[2 * segmentIdx], path[2 * segmentIdx + 1],
                        path[2 * (segmentIdx + 1)], path[2 * (segmentIdx + 1) + 1], outT);
                if (distSq <= sAlignmentToleranceSq) {
                    float t = outT[0];
                    if (t > prevT) {
                        prevT = t;
                        found = true;
                        break;
                    }
                }
                segmentIdx++;
                prevT = -0.01f;
            }
            if (!found) return false;
            lastChar = c;
        }
        return true;
    }

    // ── DTW distance ─────────────────────────────────────────────────────────

    private static float dtwDistanceSq(float[] path1, float[] path2) {
        int len = N_PTS;
        float[] cost = new float[len * len];
        float infinity = Float.MAX_VALUE;

        for (int i = 0; i < len; i++) {
            for (int j = Math.max(0, i - DTW_BAND); j <= Math.min(len - 1, i + DTW_BAND); j++) {
                float dx = path1[2*i] - path2[2*j];
                float dy = path1[2*i+1] - path2[2*j+1];
                float dist = dx*dx + dy*dy;
                float minPrev;
                if (i == 0 && j == 0) {
                    minPrev = 0;
                } else {
                    minPrev = infinity;
                    if (i > 0 && j >= i - DTW_BAND) minPrev = Math.min(minPrev, cost[(i-1)*len + j]);
                    if (j > 0 && i >= j - DTW_BAND) minPrev = Math.min(minPrev, cost[i*len + (j-1)]);
                    if (i > 0 && j > 0) minPrev = Math.min(minPrev, cost[(i-1)*len + (j-1)]);
                }
                cost[i*len + j] = dist + minPrev;
            }
        }
        return cost[(len-1)*len + (len-1)];
    }

    // ── Core ranking ─────────────────────────────────────────────────────────

    private static class RankResult {
        final SuggestionResults results;
        final float bestScore;
        RankResult(SuggestionResults r, float s) { results = r; bestScore = s; }
    }

    private static RankResult rankCoreL2(
            List<IndexEntry> candidates,
            float[] inputVec, float inputLength,
            float[][] charToPos,
            Keyboard keyboard,
            InputPointers pointers,
            int maxResults,
            java.util.Set<String> predictionSet,
            String nodeSignature,
            boolean isSandbox
    ) {
        if (sNodeFilterEnabled && sNodeFilterBeforeScoring && !nodeSignature.isEmpty()) {
            candidates = lcsFilter(candidates, nodeSignature);
        }
        if (candidates == null || candidates.isEmpty()) return null;

        Character loopLetter = detectDoubleLetterLoop(pointers, charToPos, keyboard);
        Character wiggleLetter = detectWiggledLetter(pointers, charToPos, keyboard);
        Character dwellLetter = detectDwelledLetter(pointers, keyboard, charToPos);

        int m = candidates.size();
        float[] scores = new float[m];
        int[]   order  = new int[m];
        float[] topScores = new float[maxResults];
        Arrays.fill(topScores, -Float.MAX_VALUE);
        float threshold = -Float.MAX_VALUE;

        float[] candidatePath = new float[N_PTS * 2];
        for (int i = 0; i < m; i++) {
            IndexEntry e = candidates.get(i);
            String lower = getLowerCase(e.word);
            e.unpackPath(candidatePath);

            float toleranceMultiplier = 1.0f;
            if (sGestureDict != null && isSandbox) {
                WordEntry we = sGestureDict.getEntry(lower);
                if (we != null && we.pathCount() > 1) {
                    toleranceMultiplier = 1.0f + sToleranceBoost * (we.pathCount() - 1);
                }
            }

            boolean seqMatch = isSequenceMatch(lower, inputVec, charToPos);
            float seqPenalty = seqMatch ? 0f : -0.4f;
            boolean isPredicted = predictionSet != null && predictionSet.contains(lower);
            float predBonus = isPredicted ? 0.15f : 0f;
            float lenPenalty = -Math.abs(inputLength - e.pathLen) * 0.4f;
            Integer ub = sUserBoost.get(lower);
            float userBonus = ub != null ? sUserBoostCache[ub] : 0f;

            float trigramBonus = 0f;
            if (sGestureDict != null && sPrevWord1 != null && sPrevWord2 != null) {
                int triFreq = sGestureDict.getTrigramFrequency(sPrevWord1, sPrevWord2, lower);
                if (triFreq > 0) trigramBonus = (float) (Math.log(triFreq + 1) * TRIGRAM_WEIGHT);
            }

            float bonuses = e.freqBonus + seqPenalty + predBonus + lenPenalty + userBonus + trigramBonus;

            if (loopLetter != null && lower.contains("" + loopLetter + loopLetter)) {
                bonuses += 0.4f;
            }
            if (wiggleLetter != null && lower.indexOf(wiggleLetter) >= 0) {
                bonuses += 0.3f;
            }
            if (dwellLetter != null) {
                if (lower.indexOf(dwellLetter) >= 0) {
                    bonuses += 0.2f;
                    if (lower.contains("" + dwellLetter + dwellLetter)) {
                        bonuses += 0.15f;
                    }
                }
            }

            float maxL2 = (threshold == -Float.MAX_VALUE) ? Float.MAX_VALUE : (bonuses - threshold);
            float distance;
            if (maxL2 <= 0f) {
                distance = Float.MAX_VALUE;
            } else {
                distance = l2(inputVec, candidatePath, maxL2) * toleranceMultiplier;
            }
            float score = -distance + bonuses;
            scores[i] = score;
            order[i] = i;

            if (score > threshold) {
                threshold = updateThreshold(topScores, score);
            }
        }

        for (int i = 1; i < m; i++) {
            int key = order[i];
            float ks = scores[key];
            int j = i - 1;
            while (j >= 0 && scores[order[j]] < ks) {
                order[j + 1] = order[j];
                j--;
            }
            order[j + 1] = key;
        }

        int take = Math.min(maxResults, m);
        String topWord = null;
        int topWordLen = 0;
        if (take > 0) {
            IndexEntry top = candidates.get(order[0]);
            topWord = getLowerCase(top.word);
            topWordLen = topWord.length();
        }
        int nodeSigLen = (nodeSignature != null) ? nodeSignature.length() : 0;
        boolean earlyLift = (topWordLen >= nodeSigLen + EARLY_LIFT_MIN_DELTA);

        int completionsCount = 0;
        List<String> completions = null;
        if (earlyLift && topWord != null && sFullIndex != null && sFullIndex.sandboxTrie != null) {
            completions = getWordCompletions(topWord, sFullIndex.sandboxTrie, 3);
            completionsCount = Math.min(3, completions.size());
        }

        SuggestionResults result = new SuggestionResults(take + completionsCount, false, false);
        int baseScore = 1_000_000;
        for (int rank = 0; rank < take; rank++) {
            IndexEntry e = candidates.get(order[rank]);
            String displayWord = e.word;
            if (sShowEngineId) displayWord += (isSandbox ? " S" : " D");
            result.add(new SuggestedWordInfo(
                    displayWord, "",
                    baseScore - rank * 1000,
                    SuggestedWordInfo.KIND_CORRECTION,
                    Dictionary.DICTIONARY_USER_TYPED,
                    SuggestedWordInfo.NOT_AN_INDEX,
                    SuggestedWordInfo.NOT_A_CONFIDENCE
            ));
        }
        if (completions != null) {
            for (String comp : completions) {
                if (completionsCount-- <= 0) break;
                result.add(new SuggestedWordInfo(
                        comp, "",
                        baseScore - (take + completionsCount + 1) * 1000,
                        SuggestedWordInfo.KIND_PREDICTION,
                        Dictionary.DICTIONARY_USER_TYPED,
                        SuggestedWordInfo.NOT_AN_INDEX,
                        SuggestedWordInfo.NOT_A_CONFIDENCE
                ));
            }
        }
        return new RankResult(result, scores[order[0]]);
    }

    private static RankResult rankCoreDTW(
            List<IndexEntry> candidates,
            float[] inputVec, float inputLength,
            float[][] charToPos,
            Keyboard keyboard,
            InputPointers pointers,
            int maxResults,
            java.util.Set<String> predictionSet
    ) {
        if (candidates == null || candidates.isEmpty()) return null;

        Character loopLetter = detectDoubleLetterLoop(pointers, charToPos, keyboard);
        Character wiggleLetter = detectWiggledLetter(pointers, charToPos, keyboard);
        Character dwellLetter = detectDwelledLetter(pointers, keyboard, charToPos);

        int m = candidates.size();
        float[] scores = new float[m];
        int[]   order  = new int[m];
        float[] topScores = new float[maxResults];
        Arrays.fill(topScores, -Float.MAX_VALUE);
        float threshold = -Float.MAX_VALUE;

        float[] candidatePath = new float[N_PTS * 2];
        for (int i = 0; i < m; i++) {
            IndexEntry e = candidates.get(i);
            String lower = getLowerCase(e.word);
            e.unpackPath(candidatePath);

            float dtwSq = dtwDistanceSq(inputVec, candidatePath);
            float distance = (float) Math.sqrt(dtwSq);

            boolean seqMatch = isSequenceMatch(lower, inputVec, charToPos);
            float seqPenalty = seqMatch ? 0f : -0.4f;
            boolean isPredicted = predictionSet != null && predictionSet.contains(lower);
            float predBonus = isPredicted ? 0.15f : 0f;
            float lenPenalty = -Math.abs(inputLength - e.pathLen) * 0.4f;
            Integer ub = sUserBoost.get(lower);
            float userBonus = ub != null ? sUserBoostCache[ub] : 0f;

            float trigramBonus = 0f;
            if (sGestureDict != null && sPrevWord1 != null && sPrevWord2 != null) {
                int triFreq = sGestureDict.getTrigramFrequency(sPrevWord1, sPrevWord2, lower);
                if (triFreq > 0) trigramBonus = (float) (Math.log(triFreq + 1) * TRIGRAM_WEIGHT);
            }

            float bonuses = e.freqBonus + seqPenalty + predBonus + lenPenalty + userBonus + trigramBonus;

            if (loopLetter != null && lower.contains("" + loopLetter + loopLetter)) {
                bonuses += 0.4f;
            }
            if (wiggleLetter != null && lower.indexOf(wiggleLetter) >= 0) {
                bonuses += 0.3f;
            }
            if (dwellLetter != null) {
                if (lower.indexOf(dwellLetter) >= 0) {
                    bonuses += 0.2f;
                    if (lower.contains("" + dwellLetter + dwellLetter)) {
                        bonuses += 0.15f;
                    }
                }
            }

            float score = -distance + bonuses;
            scores[i] = score;
            order[i] = i;

            if (score > threshold) {
                threshold = updateThreshold(topScores, score);
            }
        }

        for (int i = 1; i < m; i++) {
            int key = order[i];
            float ks = scores[key];
            int j = i - 1;
            while (j >= 0 && scores[order[j]] < ks) {
                order[j + 1] = order[j];
                j--;
            }
            order[j + 1] = key;
        }

        int take = Math.min(maxResults, m);
        SuggestionResults result = new SuggestionResults(take, false, false);
        int baseScore = 1_000_000;
        for (int rank = 0; rank < take; rank++) {
            IndexEntry e = candidates.get(order[rank]);
            String displayWord = e.word;
            if (sShowEngineId) displayWord += " D";
            result.add(new SuggestedWordInfo(
                    displayWord, "",
                    baseScore - rank * 1000,
                    SuggestedWordInfo.KIND_CORRECTION,
                    Dictionary.DICTIONARY_USER_TYPED,
                    SuggestedWordInfo.NOT_AN_INDEX,
                    SuggestedWordInfo.NOT_A_CONFIDENCE
            ));
        }
        return new RankResult(result, scores[order[0]]);
    }

    public static List<String> getWordCompletions(String baseWord, TrieNode sandboxTrie, int maxResults) {
        if (baseWord == null || baseWord.isEmpty() || sandboxTrie == null) return Collections.emptyList();
        String seq = canonicalNodeSeq(baseWord);
        TrieNode node = sandboxTrie;
        for (int i = 0; i < seq.length(); i++) {
            node = node.children.get(seq.charAt(i));
            if (node == null) return Collections.emptyList();
        }
        List<IndexEntry> all = new ArrayList<>();
        node.collectAll(all);
        all.sort((a, b) -> Integer.compare(b.frequency, a.frequency));
        List<String> completions = new ArrayList<>();
        String lowerBase = baseWord.toLowerCase(Locale.ROOT);
        for (IndexEntry e : all) {
            String w = getLowerCase(e.word);
            if (w.length() > lowerBase.length() && w.startsWith(lowerBase)) {
                completions.add(e.word);
                if (completions.size() >= maxResults) break;
            }
        }
        return completions;
    }

    // ── Main entry point ─────────────────────────────────────────────────────

    public static SuggestionResults rankByIndex(
            GestureIndex index,
            InputPointers pointers,
            Keyboard keyboard,
            int maxResults,
            java.util.Set<String> predictionSet
    ) {
        // Reload settings at the start of each gesture so toggles/sliders apply immediately
        reloadSettings();

        int n = pointers.getPointerSize();
        SuggestionResults empty = new SuggestionResults(1, false, false);
        if (n < 2 || index == null) return empty;

        if (sFallbackFrames == 0) sUseFallback = false;

        int[] xs = pointers.getXCoordinates();
        int[] ys = pointers.getYCoordinates();
        float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;

        float[] rawFlat = new float[n * 2];
        for (int i = 0; i < n; i++) {
            rawFlat[2 * i]     = xs[i] / kw;
            rawFlat[2 * i + 1] = ys[i] / kh;
        }
        float[] inputVec = resampleFlat(rawFlat, n, N_PTS);
        float inputLength = pathLength(inputVec);
        float[][] charToPos = index.charToPos;

        sLastInputVec = inputVec;
        sLastInputLength = inputLength;
        sLastCharToPos = charToPos;
        sLastKeyboard = keyboard;
        sLastPointers = pointers;

        String nodeSignature = extractNodeSignature(rawFlat, n, charToPos);
        sLastNodeSignature = nodeSignature;

        List<Character> startLetters = nearestLettersFromMap(rawFlat[0], rawFlat[1], charToPos);
        List<Character> endLetters   = nearestLettersFromMap(rawFlat[2*(n-1)], rawFlat[2*(n-1)+1], charToPos);

        Log.i(TAG, "nodes=" + nodeSignature + " start=" + startLetters + " end=" + endLetters);

        // Sandbox
        GestureIndex sandbox = (sSandboxIndex != null) ? sSandboxIndex : index.sandboxIndex;
        if (sUseSandbox && sandbox != null && !sUseFallback) {
            List<IndexEntry> sandCandidates = new ArrayList<>();
            for (char first : startLetters) {
                List<IndexEntry> list = sandbox.byFirst.get(first);
                if (list != null) sandCandidates.addAll(list);
            }
            Log.i(TAG, "sandbox candidates: " + sandCandidates.size());
            if (!sandCandidates.isEmpty()) {
                List<IndexEntry> filtered = new ArrayList<>();
                for (IndexEntry e : sandCandidates) {
                    String lower = getLowerCase(e.word);
                    if (!lower.isEmpty() && endLetters.contains(lower.charAt(lower.length() - 1))) {
                        filtered.add(e);
                    }
                }
                Log.i(TAG, "sandbox after end filter: " + filtered.size());
                if (filtered.isEmpty()) filtered = sandCandidates;

                if (sNodeFilterEnabled && !sNodeFilterBeforeScoring) {
                    filtered = lcsFilter(filtered, nodeSignature);
                }

                if (!filtered.isEmpty()) {
                    long t0 = System.currentTimeMillis();
                    RankResult sand = rankCoreL2(filtered, inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet, nodeSignature, true);
                    long t1 = System.currentTimeMillis();
                    Log.i(TAG, "sandbox L2 took " + (t1-t0) + "ms, bestScore=" + (sand != null ? sand.bestScore : -999));
                    if (sand != null && sand.bestScore >= sSandboxThreshold) {
                        sFallbackFrames = 0;
                        Log.i(TAG, "sandbox accepted");
                        return sand.results;
                    } else {
                        sFallbackFrames++;
                        Log.i(TAG, "sandbox score low (" + sFallbackFrames + "/" + FALLBACK_GRACE_FRAMES + ")");
                        if (sFallbackFrames >= FALLBACK_GRACE_FRAMES) {
                            sUseFallback = true;
                            Log.i(TAG, "sandbox permanently disabled for this gesture");
                        }
                    }
                }
            }
        }

        // Full dictionary (DTW) – SKIP if sandbox is restricted
        if (sRestrictToSandbox || !sUseDtw) {
            return empty;
        }

        List<IndexEntry> fullCandidates = new ArrayList<>();
        for (char first : startLetters) {
            List<IndexEntry> list = index.byFirst.get(first);
            if (list != null) fullCandidates.addAll(list);
        }
        Log.i(TAG, "full dict candidates: " + fullCandidates.size());
        if (fullCandidates.isEmpty()) return empty;

        List<IndexEntry> filtered = new ArrayList<>();
        for (IndexEntry e : fullCandidates) {
            String lower = getLowerCase(e.word);
            if (lower.isEmpty()) continue;
            if (!endLetters.contains(lower.charAt(lower.length() - 1))) continue;
            filtered.add(e);
        }
        if (filtered.isEmpty()) filtered = fullCandidates;
        Log.i(TAG, "full dict after end filter: " + filtered.size());

        if (!nodeSignature.isEmpty()) {
            long t0 = System.currentTimeMillis();
            List<IndexEntry> lcsFiltered = lcsFilter(filtered, nodeSignature);
            long t1 = System.currentTimeMillis();
            Log.i(TAG, "LCS filter took " + (t1-t0) + "ms, from " + filtered.size() + " to " + lcsFiltered.size());
            if (!lcsFiltered.isEmpty()) filtered = lcsFiltered;
        }

        long t0 = System.currentTimeMillis();
        RankResult full = rankCoreDTW(filtered, inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet);
        long t1 = System.currentTimeMillis();
        Log.i(TAG, "full DTW took " + (t1-t0) + "ms on " + filtered.size() + " candidates");
        return full != null ? full.results : empty;
    }

    public static SuggestionResults retryWithFallback(int maxResults, java.util.Set<String> predictionSet) {
        if (sLastInputVec == null || sLastCharToPos == null || sLastKeyboard == null || sLastPointers == null || sFullIndex == null) {
            return new SuggestionResults(1, false, false);
        }
        float[][] charToPos = sLastCharToPos;
        String nodeSignature = sLastNodeSignature;
        List<Character> startLetters = nearestLettersFromMap(sLastInputVec[0], sLastInputVec[1], charToPos);
        List<Character> endLetters   = nearestLettersFromMap(sLastInputVec[2*(sLastInputVec.length/2-1)], sLastInputVec[2*(sLastInputVec.length/2-1)+1], charToPos);

        List<IndexEntry> fullCandidates = new ArrayList<>();
        for (char first : startLetters) {
            List<IndexEntry> list = sFullIndex.byFirst.get(first);
            if (list != null) fullCandidates.addAll(list);
        }
        if (fullCandidates.isEmpty()) return new SuggestionResults(1, false, false);

        List<IndexEntry> filtered = new ArrayList<>();
        for (IndexEntry e : fullCandidates) {
            String lower = getLowerCase(e.word);
            if (lower.isEmpty()) continue;
            if (!endLetters.contains(lower.charAt(lower.length() - 1))) continue;
            filtered.add(e);
        }
        if (filtered.isEmpty()) filtered = fullCandidates;

        if (!nodeSignature.isEmpty()) {
            filtered = lcsFilter(filtered, nodeSignature);
            if (filtered.isEmpty()) filtered = fullCandidates;
        }

        RankResult full = rankCoreDTW(filtered, sLastInputVec, sLastInputLength, charToPos, sLastKeyboard, sLastPointers, maxResults, predictionSet);
        return full != null ? full.results : new SuggestionResults(1, false, false);
    }

    // ── Internals ─────────────────────────────────────────────────────────────

    private static float sqDistanceToSegment(float px, float py, float ax, float ay, float bx, float by, float[] outT) {
        float dx = bx - ax;
        float dy = by - ay;
        float segmentLenSq = dx * dx + dy * dy;
        if (segmentLenSq < 1e-9f) {
            outT[0] = 0f;
            return (px - ax) * (px - ax) + (py - ay) * (py - ay);
        }
        float t = ((px - ax) * dx + (py - ay) * dy) / segmentLenSq;
        if (t < 0f) t = 0f;
        else if (t > 1f) t = 1f;
        outT[0] = t;
        float closestX = ax + t * dx;
        float closestY = ay + t * dy;
        return (px - closestX) * (px - closestX) + (py - closestY) * (py - closestY);
    }

    private static float pathLength(float[] path) {
        float len = 0;
        int n = path.length / 2;
        for (int i = 0; i < n - 1; i++) {
            float dx = path[2 * (i + 1)] - path[2 * i];
            float dy = path[2 * (i + 1) + 1] - path[2 * i + 1];
            len += (float) Math.sqrt(dx * dx + dy * dy);
        }
        return len;
    }

    static float[][] buildCharToPos(Keyboard keyboard) {
        float[][] map = new float[26][2];
        float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;
        for (Key key : keyboard.getSortedKeys()) {
            int code = key.getCode();
            if (!isAsciiLetter(code)) continue;
            int idx = Character.toLowerCase((char) code) - 'a';
            Rect hitBox = key.getHitBox();
            map[idx][0] = hitBox.exactCenterX() / kw;
            map[idx][1] = hitBox.exactCenterY() / kh;
        }
        return map;
    }

    static float[] wordPath(String word, float[][] charToPos) {
        float[] pts = new float[word.length() * 2];
        int count = 0;
        float lastX = -1f, lastY = -1f;
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            int idx = c - 'a';
            if (idx < 0 || idx >= 26) continue;
            float[] p = charToPos[idx];
            if (count == 0 || p[0] != lastX || p[1] != lastY) {
                pts[2 * count] = p[0];
                pts[2 * count + 1] = p[1];
                lastX = p[0]; lastY = p[1];
                count++;
            }
        }
        return resampleFlat(pts, count, N_PTS);
    }

    static float[] resampleFlat(float[] pts, int numPts, int n) {
        if (numPts == 0) return new float[n * 2];
        if (numPts == 1) {
            float[] r = new float[n * 2];
            float x = pts[0], y = pts[1];
            for (int i = 0; i < n; i++) { r[2*i] = x; r[2*i+1] = y; }
            return r;
        }
        float[] cum = new float[numPts];
        for (int i = 1; i < numPts; i++) {
            float dx = pts[2 * i] - pts[2 * (i - 1)];
            float dy = pts[2 * i + 1] - pts[2 * (i - 1) + 1];
            cum[i] = cum[i-1] + (float) Math.sqrt(dx*dx + dy*dy);
        }
        float total = cum[numPts-1];
        if (total < 1e-9f) {
            float[] r = new float[n * 2];
            float x = pts[0], y = pts[1];
            for (int i = 0; i < n; i++) { r[2*i] = x; r[2*i+1] = y; }
            return r;
        }
        float[] result = new float[n * 2];
        int seg = 0;
        for (int i = 0; i < n; i++) {
            float t = total * i / (n - 1);
            while (seg < numPts - 2 && cum[seg + 1] < t) seg++;
            float segLen = cum[seg+1] - cum[seg];
            float alpha  = (segLen > 1e-9f) ? (t - cum[seg]) / segLen : 0f;
            result[2*i]   = pts[2 * seg] + alpha * (pts[2 * (seg + 1)] - pts[2 * seg]);
            result[2*i+1] = pts[2 * seg + 1] + alpha * (pts[2 * (seg + 1) + 1] - pts[2 * seg + 1]);
        }
        return result;
    }

    static float[] resample(List<float[]> pts, int n) {
        float[] flat = new float[pts.size() * 2];
        for (int i = 0; i < pts.size(); i++) {
            flat[2*i] = pts.get(i)[0];
            flat[2*i+1] = pts.get(i)[1];
        }
        return resampleFlat(flat, pts.size(), n);
    }

    private static float l2(float[] a, float[] b, float maxL2) {
        float s = 0;
        int n = a.length / 2;
        float limitSq = maxL2 * maxL2;
        for (int i = 0; i < n; i++) {
            float dx = a[2 * i] - b[2 * i];
            float dy = a[2 * i + 1] - b[2 * i + 1];
            float distSq = dx * dx + dy * dy;
            if (i == 0 || i == n - 1) s += distSq * 2.0f;
            else s += distSq;
            if (s > limitSq) return Float.MAX_VALUE;
        }
        return (float) Math.sqrt(s);
    }

    private static float updateThreshold(float[] topScores, float newScore) {
        int minIdx = 0;
        for (int i = 1; i < topScores.length; i++) {
            if (topScores[i] < topScores[minIdx]) minIdx = i;
        }
        if (newScore > topScores[minIdx]) {
            topScores[minIdx] = newScore;
        }
        float min = topScores[0];
        for (int i = 1; i < topScores.length; i++) {
            if (topScores[i] < min) min = topScores[i];
        }
        return min;
    }

    public static boolean hasLoopAtEnd(InputPointers pointers, Keyboard keyboard) {
        int n = pointers.getPointerSize();
        if (n < 6) return false;
        int[] xs = pointers.getXCoordinates();
        int[] ys = pointers.getYCoordinates();
        int pointsToCheck = Math.min(n / 2, 10);
        if (pointsToCheck < 4) pointsToCheck = 4;
        int startIdx = n - pointsToCheck;
        float pathLen = 0f;
        for (int i = startIdx; i < n - 1; i++) {
            float dx = xs[i+1] - xs[i];
            float dy = ys[i+1] - ys[i];
            pathLen += (float) Math.sqrt(dx * dx + dy * dy);
        }
        float startEndX = xs[n - 1] - xs[startIdx];
        float startEndY = ys[n - 1] - ys[startIdx];
        float displacement = (float) Math.sqrt(startEndX * startEndX + startEndY * startEndY);
        float kw = keyboard.mOccupiedWidth;
        if (pathLen < kw * 0.02f) return false;
        return pathLen > 2.0f * displacement;
    }

    // ── Permanent Gesture Dictionary ─────────────────────────────────────────

    public static class WordEntry {
        public final String word;
        public int frequency;
        private final List<float[]> paths = new ArrayList<>();

        public WordEntry(String w, float[] p, int f) {
            this.word = w;
            this.frequency = f;
            if (p != null && p.length == N_PTS * 2) paths.add(p.clone());
        }

        public float[] path() { return paths.isEmpty() ? null : paths.get(0); }
        public int pathCount() { return paths.size(); }

        public void addPath(float[] newPath, int maxPaths) {
            if (paths.size() < maxPaths) {
                paths.add(newPath.clone());
            } else {
                float[] first = paths.get(0);
                for (int i = 0; i < N_PTS * 2; i++) {
                    first[i] = first[i] * 0.7f + newPath[i] * 0.3f;
                }
            }
        }
    }

    private static class GestureDictionary {
        private final Map<String, WordEntry> entries = new HashMap<>();
        private final Map<Long, Map<String, Integer>> trigrams = new HashMap<>();

        public void addOrUpdateWord(String word, float[] path, int freqIncrement) {
            WordEntry entry = entries.get(word);
            if (entry == null) {
                if (freqIncrement <= 0) return;
                entry = new WordEntry(word, path, freqIncrement);
                entries.put(word, entry);
            } else {
                entry.frequency += freqIncrement;
                if (entry.frequency < 0) entry.frequency = 0;
                if (path != null && path.length == N_PTS * 2) {
                    entry.addPath(path, sPathsPerWord);
                }
            }
        }

        public WordEntry getEntry(String word) { return entries.get(word); }
        public boolean contains(String word) { return entries.containsKey(word); }
        public Collection<WordEntry> getEntries() { return entries.values(); }

        public void updateTrigram(String prevWord1, String prevWord2, String nextWord) {
            long hash = trigramHash(prevWord1, prevWord2);
            Map<String, Integer> nextMap = trigrams.get(hash);
            if (nextMap == null) {
                nextMap = new HashMap<>();
                trigrams.put(hash, nextMap);
            }
            Integer freq = nextMap.get(nextWord);
            nextMap.put(nextWord, (freq == null) ? 1 : freq + 1);
        }

        public int getTrigramFrequency(String prevWord1, String prevWord2, String nextWord) {
            long hash = trigramHash(prevWord1, prevWord2);
            Map<String, Integer> nextMap = trigrams.get(hash);
            if (nextMap == null) return 0;
            Integer freq = nextMap.get(nextWord);
            return (freq != null) ? freq : 0;
        }

        public void save(File file) {
            try (DataOutputStream out = new DataOutputStream(
                    new BufferedOutputStream(new FileOutputStream(file)))) {
                out.writeInt(3);
                out.writeInt(entries.size());
                for (WordEntry we : entries.values()) {
                    out.writeUTF(we.word);
                    out.writeInt(we.frequency);
                    boolean hasPath = (we.path() != null && we.path().length == N_PTS * 2);
                    out.writeBoolean(hasPath);
                    if (hasPath) {
                        float[] p = we.path();
                        for (int i = 0; i < N_PTS * 2; i++) out.writeFloat(p[i]);
                    }
                }
                out.writeInt(trigrams.size());
                for (Map.Entry<Long, Map<String, Integer>> triEntry : trigrams.entrySet()) {
                    out.writeLong(triEntry.getKey());
                    Map<String, Integer> nextMap = triEntry.getValue();
                    out.writeInt(nextMap.size());
                    for (Map.Entry<String, Integer> next : nextMap.entrySet()) {
                        out.writeUTF(next.getKey());
                        out.writeInt(next.getValue());
                    }
                }
            } catch (IOException e) {
                android.util.Log.e(TAG, "Error saving gesture dict", e);
            }
        }

        public void load(File file) {
            if (!file.exists()) return;
            entries.clear();
            trigrams.clear();
            try (DataInputStream in = new DataInputStream(
                    new BufferedInputStream(new FileInputStream(file)))) {
                int version = in.readInt();
                if (version < 1 || version > 3) return;
                int count = in.readInt();
                for (int i = 0; i < count; i++) {
                    String word = in.readUTF();
                    int freq = in.readInt();
                    boolean hasPath = in.readBoolean();
                    float[] path = null;
                    if (hasPath) {
                        path = new float[N_PTS * 2];
                        for (int j = 0; j < N_PTS * 2; j++) {
                            path[j] = in.readFloat();
                        }
                    }
                    entries.put(word, new WordEntry(word, path, freq));
                }
                if (version >= 3) {
                    int triCount = in.readInt();
                    for (int i = 0; i < triCount; i++) {
                        long hash = in.readLong();
                        int nextCount = in.readInt();
                        Map<String, Integer> nextMap = new HashMap<>();
                        for (int j = 0; j < nextCount; j++) {
                            String nextWord = in.readUTF();
                            int freq = in.readInt();
                            nextMap.put(nextWord, freq);
                        }
                        trigrams.put(hash, nextMap);
                    }
                }
            } catch (IOException e) {
                android.util.Log.e(TAG, "Error loading gesture dict", e);
                entries.clear();
                trigrams.clear();
            }
        }
    }

    private static class GestureEvent {
        String word;
        float[] path;
        List<IndexEntry> candidates;
        boolean backspaced;
        boolean corrected;
        String correctedWord;
    }
}