/*
 * SwipeGestureEngine – Phase 3: Full Dual‑Engine Pipeline + Manual Deep Search
 * Implements Primary/Fallback roles, parallel mode, per‑engine scopes, and strict sandbox.
 */
package helium314.keyboard.latin.gesture;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.database.Cursor;
import android.graphics.Rect;
import android.provider.UserDictionary;
import android.util.Log;
import helium314.keyboard.keyboard.Key;
import helium314.keyboard.keyboard.Keyboard;
import helium314.keyboard.latin.SuggestedWords.SuggestedWordInfo;
import helium314.keyboard.latin.common.InputPointers;
import helium314.keyboard.latin.dictionary.Dictionary;
import helium314.keyboard.latin.utils.SuggestionResults;

import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class SwipeGestureEngine {

    // ─── Preference Keys (matching the design document) ──────────────────
    private static final String PREF_ENABLE_L2 = "gesture_enable_l2";
    private static final String PREF_ENABLE_DTW = "gesture_enable_dtw";
    private static final String PREF_PRIMARY_ENGINE = "gesture_primary_engine";
    private static final String PREF_FALLBACK_ENGINE = "gesture_fallback_engine";
    private static final String PREF_PARALLEL_MODE = "gesture_parallel_mode";

    private static final String PREF_SCOPE_L2 = "gesture_search_scope_l2";
    private static final String PREF_SCOPE_DTW = "gesture_search_scope_dtw";
    private static final String PREF_CONFIDENCE_L2 = "gesture_confidence_threshold_l2";
    private static final String PREF_CONFIDENCE_DTW = "gesture_confidence_threshold_dtw";
    private static final String PREF_STRICT_SANDBOX_L2 = "gesture_strict_sandbox_l2";
    private static final String PREF_STRICT_SANDBOX_DTW = "gesture_strict_sandbox_dtw";
    private static final String PREF_PARTICIPATE_DEEP_L2 = "gesture_participate_deep_search_l2";
    private static final String PREF_PARTICIPATE_DEEP_DTW = "gesture_participate_deep_search_dtw";

    private static final String PREF_SHOW_ENGINE_ID = "gesture_show_engine_id";
    private static final String PREF_SANDBOX_SIZE = "gesture_sandbox_size";
    private static final String PREF_EVICTION_POLICY = "gesture_eviction_policy";

    // ─── Tunable Constants ──────────────────────────────────────────────────
    private static final int N_PTS = 20;
    private static final int DTW_BAND = 3;
    private static final float FREQ_WEIGHT = 0.15f;
    private static final float PROXIMITY_RADIUS = 0.035f;
    private static final float ALIGNMENT_TOLERANCE_SQ = 0.025f;
    private static final float SANDBOX_FALLBACK_THRESHOLD = -0.15f;

    private static final String TAG = "GestureEngine";
    private static final String SCOPE_SANDBOX = "sandbox";
    private static final String SCOPE_FULL = "full";
    private static final String SCOPE_SANDBOX_FIRST = "sandbox_first";

    // ─── Core State ──────────────────────────────────────────────────────────
    private static Context sAppContext = null;
    private static GestureDictionary sGestureDict = null;
    private static File sDictFile = null;

    // Indexes (built per keyboard layout)
    private static GestureIndex sFullIndex = null;      // Main dictionary + learned words
    private static GestureIndex sSandboxIndex = null;   // User‑learned + history only
    private static int sLastFingerprint = -1;

    // Cached Settings
    private static boolean sEnableL2 = false;
    private static boolean sEnableDTW = false;
    private static String sPrimaryEngine = "dtw";
    private static String sFallbackEngine = "l2";
    private static boolean sParallelMode = false;
    private static String sScopeL2 = SCOPE_SANDBOX_FIRST;
    private static String sScopeDTW = SCOPE_FULL;
    private static float sConfidenceL2 = -0.15f;
    private static float sConfidenceDTW = -0.15f;
    private static boolean sStrictSandboxL2 = false;
    private static boolean sStrictSandboxDTW = false;
    private static boolean sParticipateDeepL2 = true;
    private static boolean sParticipateDeepDTW = true;
    private static boolean sShowEngineId = false;

    // Manual deep search flag
    private static boolean sManualDeepSearchRequested = false;

    // Learning
    private static final List<GestureEvent> sHoldingPen = new ArrayList<>();
    private static boolean mIncognito = false;
    private static String sPrevWord1 = null;
    private static String sPrevWord2 = null;

    // User boost cache
    private static final ConcurrentHashMap<String, Integer> sUserBoost = new ConcurrentHashMap<>();
    private static final float[] sUserBoostCache = new float[51];
    static {
        for (int i = 0; i <= 50; i++) {
            sUserBoostCache[i] = (float) Math.log(i + 1) * 0.08f;
        }
    }

    // Last gesture data (for manual deep search)
    private static float[] sLastInputVec = null;
    private static float sLastInputLength = 0f;
    private static String sLastNodeSignature = null;
    private static Keyboard sLastKeyboard = null;
    private static InputPointers sLastPointers = null;

    // ─── Settings Listener ──────────────────────────────────────────────────
    private static final OnSharedPreferenceChangeListener sPrefListener = (prefs, key) -> {
        if (key == null) return;
        reloadSettings(prefs);
    };

    // ─── Public API ──────────────────────────────────────────────────────────
    public static void initialize(Context context) {
        if (sAppContext != null) return;
        sAppContext = context.getApplicationContext();
        sDictFile = new File(sAppContext.getFilesDir(), "gesture_user_data.bin");
        sGestureDict = new GestureDictionary();
        sGestureDict.load(sDictFile);

        SharedPreferences prefs = sAppContext.getSharedPreferences("gesture_settings", Context.MODE_PRIVATE);
        prefs.registerOnSharedPreferenceChangeListener(sPrefListener);
        reloadSettings(prefs);
        Log.i(TAG, "initialize: loaded " + sGestureDict.getEntries().size() + " learned words");
    }

    private static void reloadSettings(SharedPreferences prefs) {
        sEnableL2 = prefs.getBoolean(PREF_ENABLE_L2, false);
        sEnableDTW = prefs.getBoolean(PREF_ENABLE_DTW, false);
        sPrimaryEngine = prefs.getString(PREF_PRIMARY_ENGINE, "dtw");
        sFallbackEngine = prefs.getString(PREF_FALLBACK_ENGINE, "l2");
        sParallelMode = prefs.getBoolean(PREF_PARALLEL_MODE, false);

        sScopeL2 = prefs.getString(PREF_SCOPE_L2, SCOPE_SANDBOX_FIRST);
        sScopeDTW = prefs.getString(PREF_SCOPE_DTW, SCOPE_FULL);
        sConfidenceL2 = prefs.getFloat(PREF_CONFIDENCE_L2, -0.15f);
        sConfidenceDTW = prefs.getFloat(PREF_CONFIDENCE_DTW, -0.15f);
        sStrictSandboxL2 = prefs.getBoolean(PREF_STRICT_SANDBOX_L2, false);
        sStrictSandboxDTW = prefs.getBoolean(PREF_STRICT_SANDBOX_DTW, false);
        sParticipateDeepL2 = prefs.getBoolean(PREF_PARTICIPATE_DEEP_L2, true);
        sParticipateDeepDTW = prefs.getBoolean(PREF_PARTICIPATE_DEEP_DTW, true);

        sShowEngineId = prefs.getBoolean(PREF_SHOW_ENGINE_ID, false);

        Log.i(TAG, "Settings: L2=" + sEnableL2 + " DTW=" + sEnableDTW + " Primary=" + sPrimaryEngine +
                " Fallback=" + sFallbackEngine + " Parallel=" + sParallelMode);
    }

    public static void setPredictionContext(String prevWord1, String prevWord2) {
        sPrevWord1 = prevWord1;
        sPrevWord2 = prevWord2;
    }

    public static void setIncognitoMode(boolean incognito) {
        mIncognito = incognito;
    }

    // ─── Helper class for ranking results ──────────────────────────────────
    private static class RankResult {
        final SuggestionResults results;
        final float bestScore;
        RankResult(SuggestionResults r, float s) { results = r; bestScore = s; }
    }

    // ─── Index Building (Separate Full & Sandbox) ──────────────────────────

    public static class IndexEntry {
        public final String word;
        public final int frequency;
        public final float[] path;
        public final float pathLen;
        public final float freqBonus;

        IndexEntry(String word, float[] path, int frequency) {
            this.word = word;
            this.frequency = frequency;
            this.path = path;
            this.pathLen = pathLength(path);
            this.freqBonus = (frequency > 0) ? (float)(Math.log(frequency + 1) * FREQ_WEIGHT) : 0f;
        }
    }

    public static class GestureIndex {
        public final Map<Character, List<IndexEntry>> byFirst;
        public final float[][] charToPos;

        GestureIndex(Map<Character, List<IndexEntry>> byFirst, float[][] charToPos) {
            this.byFirst = byFirst;
            this.charToPos = charToPos;
        }
    }

    public static class TrieNode {
        Map<Character, TrieNode> children = new HashMap<>();
        List<IndexEntry> entries;

        void insert(String seq, int pos, IndexEntry entry) {
            if (pos == seq.length()) {
                if (entries == null) entries = new ArrayList<>();
                entries.add(entry);
                return;
            }
            char c = seq.charAt(pos);
            TrieNode child = children.get(c);
            if (child == null) {
                child = new TrieNode();
                children.put(c, child);
            }
            child.insert(seq, pos + 1, entry);
        }

        List<IndexEntry> getCandidates(String prefix) {
            TrieNode node = this;
            for (int i = 0; i < prefix.length(); i++) {
                char c = prefix.charAt(i);
                node = node.children.get(c);
                if (node == null) return null;
            }
            return node.entries;
        }

        void collectAll(List<IndexEntry> out) {
            if (entries != null) out.addAll(entries);
            for (TrieNode child : children.values()) child.collectAll(out);
        }
    }

    private static File indexCacheFile(int fingerprint) {
        return new File(sAppContext.getFilesDir(), "gesture_index_" + fingerprint + ".bin");
    }

    public static GestureIndex buildIndex(helium314.keyboard.latin.DictionaryFacilitator facilitator, Keyboard keyboard) {
        int fingerprint = layoutFingerprint(keyboard);
        if (fingerprint == sLastFingerprint && sFullIndex != null && sSandboxIndex != null) return sFullIndex;

        File cacheFile = indexCacheFile(fingerprint);
        if (cacheFile.exists()) {
            GestureIndex cached = loadIndexFromDisk(cacheFile, keyboard);
            if (cached != null) {
                sLastFingerprint = fingerprint;
                sFullIndex = cached;
                // Sandbox index is rebuilt from gesture dict and user history; we'll rebuild it separately.
                // For simplicity, we'll rebuild both from scratch if cache misses.
            }
        }

        float[][] charToPos = buildCharToPos(keyboard);

        // ─── 1. Full Index (Main Dictionary + Learned) ─────────────────────
        Map<Character, List<IndexEntry>> fullByFirst = new HashMap<>();
        facilitator.forEachMainDictionaryWord((raw, freqVal) -> {
            try {
                if (raw == null || facilitator.isBlacklisted(raw)) return;
                String lower = raw.toLowerCase(Locale.ROOT);
                if (lower.isEmpty()) return;
                char first = lower.charAt(0);
                if (first < 'a' || first > 'z') return;
                int freq = freqVal != null ? freqVal : 0;
                if (freq < 3) return;
                float[] path = wordPath(lower, charToPos);
                fullByFirst.computeIfAbsent(first, k -> new ArrayList<>()).add(new IndexEntry(lower, path, freq));
            } catch (Exception ignored) {}
        });

        if (sGestureDict != null) {
            for (WordEntry we : sGestureDict.getEntries()) {
                String lower = we.word.toLowerCase(Locale.ROOT);
                if (lower.isEmpty()) continue;
                char first = lower.charAt(0);
                if (first < 'a' || first > 'z') continue;
                float[] path = we.path();
                if (path == null) path = wordPath(lower, charToPos);
                int freq = Math.max(we.frequency, 10);
                fullByFirst.computeIfAbsent(first, k -> new ArrayList<>()).add(new IndexEntry(lower, path, freq));
            }
        }

        facilitator.forEachUserHistoryWord((word, freq) -> {
            try {
                if (word == null || word.length() < 2) return;
                String lower = word.toLowerCase(Locale.ROOT);
                if (facilitator.isBlacklisted(lower)) return;
                char first = lower.charAt(0);
                if (first < 'a' || first > 'z') return;
                int historyFreq = (freq != null) ? freq : 1;
                if (sGestureDict != null && sGestureDict.contains(lower)) return;
                float[] path = wordPath(lower, charToPos);
                fullByFirst.computeIfAbsent(first, k -> new ArrayList<>()).add(new IndexEntry(lower, path, historyFreq));
            } catch (Exception ignored) {}
        });

        for (List<IndexEntry> list : fullByFirst.values()) {
            list.sort((a, b) -> Integer.compare(b.frequency, a.frequency));
        }

        // ─── 2. Sandbox Index (Learned + History only) ────────────────────
        Map<Character, List<IndexEntry>> sandboxByFirst = new HashMap<>();
        if (sGestureDict != null) {
            for (WordEntry we : sGestureDict.getEntries()) {
                String lower = we.word.toLowerCase(Locale.ROOT);
                if (lower.isEmpty()) continue;
                char first = lower.charAt(0);
                if (first < 'a' || first > 'z') continue;
                float[] path = we.path();
                if (path == null) path = wordPath(lower, charToPos);
                sandboxByFirst.computeIfAbsent(first, k -> new ArrayList<>()).add(new IndexEntry(lower, path, Math.max(we.frequency, 10)));
            }
        }

        facilitator.forEachUserHistoryWord((word, freq) -> {
            try {
                if (word == null || word.length() < 2) return;
                String lower = word.toLowerCase(Locale.ROOT);
                if (facilitator.isBlacklisted(lower)) return;
                char first = lower.charAt(0);
                if (first < 'a' || first > 'z') return;
                if (sGestureDict != null && sGestureDict.contains(lower)) return;
                int historyFreq = (freq != null) ? freq : 1;
                float[] path = wordPath(lower, charToPos);
                sandboxByFirst.computeIfAbsent(first, k -> new ArrayList<>()).add(new IndexEntry(lower, path, historyFreq));
            } catch (Exception ignored) {}
        });

        for (List<IndexEntry> list : sandboxByFirst.values()) {
            list.sort((a, b) -> Integer.compare(b.frequency, a.frequency));
        }

        GestureIndex fullIndex = new GestureIndex(fullByFirst, charToPos);
        GestureIndex sandboxIndex = new GestureIndex(sandboxByFirst, charToPos);

        sFullIndex = fullIndex;
        sSandboxIndex = sandboxIndex;
        sLastFingerprint = fingerprint;

        saveIndexToDisk(cacheFile, fullIndex);
        Log.i(TAG, "buildIndex: full=" + countEntries(fullByFirst) + " sandbox=" + countEntries(sandboxByFirst));
        return sFullIndex;
    }

    private static void saveIndexToDisk(File file, GestureIndex index) {
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeInt(1);
            out.writeInt(26);
            for (int i = 0; i < 26; i++) {
                out.writeFloat(index.charToPos[i][0]);
                out.writeFloat(index.charToPos[i][1]);
            }
            out.writeInt(index.byFirst.size());
            for (Map.Entry<Character, List<IndexEntry>> e : index.byFirst.entrySet()) {
                out.writeChar(e.getKey());
                List<IndexEntry> list = e.getValue();
                out.writeInt(list.size());
                for (IndexEntry ie : list) {
                    out.writeUTF(ie.word);
                    out.writeInt(ie.frequency);
                    float[] p = ie.path;
                    for (float v : p) out.writeFloat(v);
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "Error saving index cache", e);
        }
    }

    private static GestureIndex loadIndexFromDisk(File file, Keyboard keyboard) {
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            int version = in.readInt();
            if (version != 1) return null;
            float[][] charToPos = new float[26][2];
            int posCount = in.readInt();
            for (int i = 0; i < posCount && i < 26; i++) {
                charToPos[i][0] = in.readFloat();
                charToPos[i][1] = in.readFloat();
            }
            Map<Character, List<IndexEntry>> byFirst = new HashMap<>();
            int bucketCount = in.readInt();
            for (int i = 0; i < bucketCount; i++) {
                char first = in.readChar();
                int listSize = in.readInt();
                List<IndexEntry> list = new ArrayList<>();
                for (int j = 0; j < listSize; j++) {
                    String word = in.readUTF();
                    int freq = in.readInt();
                    float[] path = new float[N_PTS * 2];
                    for (int k = 0; k < N_PTS * 2; k++) path[k] = in.readFloat();
                    list.add(new IndexEntry(word, path, freq));
                }
                byFirst.put(first, list);
            }
            return new GestureIndex(byFirst, charToPos);
        } catch (IOException e) {
            Log.e(TAG, "Error loading index cache", e);
            return null;
        }
    }

    private static int countEntries(Map<Character, List<IndexEntry>> map) {
        int count = 0;
        for (List<IndexEntry> list : map.values()) count += list.size();
        return count;
    }

    // ─── Main Ranking Pipeline ──────────────────────────────────────────────

    public static SuggestionResults rankByIndex(
            GestureIndex index,
            InputPointers pointers,
            Keyboard keyboard,
            int maxResults,
            java.util.Set<String> predictionSet
    ) {
        if (index == null) {
            Log.e(TAG, "rankByIndex: index is null");
            return new SuggestionResults(1, false, false);
        }
        int n = pointers.getPointerSize();
        SuggestionResults empty = new SuggestionResults(1, false, false);
        if (n < 2) return empty;

        // Normalize input path
        int[] xs = pointers.getXCoordinates();
        int[] ys = pointers.getYCoordinates();
        float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;
        float[] rawFlat = new float[n * 2];
        for (int i = 0; i < n; i++) {
            rawFlat[2 * i] = xs[i] / kw;
            rawFlat[2 * i + 1] = ys[i] / kh;
        }
        float[] inputVec = resampleFlat(rawFlat, n, N_PTS);
        float inputLength = pathLength(inputVec);
        float[][] charToPos = index.charToPos;

        // Cache for manual deep search
        sLastInputVec = inputVec;
        sLastInputLength = inputLength;
        sLastKeyboard = keyboard;
        sLastPointers = pointers;

        // Start/End letters
        List<Character> startLetters = nearestLettersFromMap(rawFlat[0], rawFlat[1], charToPos);
        List<Character> endLetters = nearestLettersFromMap(rawFlat[2 * (n - 1)], rawFlat[2 * (n - 1) + 1], charToPos);

        String nodeSignature = extractNodeSignature(rawFlat, n, charToPos);
        sLastNodeSignature = nodeSignature;

        Log.i(TAG, "swipe start=" + startLetters + " end=" + endLetters + " nodes=" + nodeSignature);

        // ─── HANDLE MANUAL DEEP SEARCH ────────────────────────────────────
        if (sManualDeepSearchRequested) {
            sManualDeepSearchRequested = false;
            Log.i(TAG, "Manual deep search triggered. Overriding all restrictions.");
            return runDeepSearch(inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet);
        }

        // ─── PARALLEL MODE ────────────────────────────────────────────────
        if (sParallelMode && sEnableL2 && sEnableDTW) {
            Log.i(TAG, "Parallel mode enabled. Running both engines.");
            RankResult l2Result = rankL2(inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet, sScopeL2, false);
            RankResult dtwResult = rankDTW(inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet, sScopeDTW, false);
            return mergeResults(l2Result, dtwResult, maxResults);
        }

        // ─── PIPELINE MODE ─────────────────────────────────────────────────
        boolean primaryIsL2 = "l2".equals(sPrimaryEngine);
        boolean fallbackIsL2 = "l2".equals(sFallbackEngine);

        RankResult primaryResult = null;
        boolean primaryEnabled = false;

        if (primaryIsL2 && sEnableL2) {
            primaryResult = rankL2(inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet, sScopeL2, false);
            primaryEnabled = true;
        } else if (!primaryIsL2 && sEnableDTW) {
            primaryResult = rankDTW(inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet, sScopeDTW, false);
            primaryEnabled = true;
        }

        if (!primaryEnabled) return empty;

        float primaryScore = primaryResult.bestScore;
        String primaryScope = primaryIsL2 ? sScopeL2 : sScopeDTW;
        boolean primaryStrict = primaryIsL2 ? sStrictSandboxL2 : sStrictSandboxDTW;

        // Determine if fallback is needed
        boolean needsFallback = false;
        float fallbackThreshold = primaryIsL2 ? sConfidenceL2 : sConfidenceDTW;

        if (primaryScope.equals(SCOPE_SANDBOX) && !primaryStrict) {
            if (primaryScore < fallbackThreshold) needsFallback = true;
        } else if (primaryScope.equals(SCOPE_SANDBOX_FIRST) && !primaryStrict) {
            if (primaryScore < fallbackThreshold) needsFallback = true;
        }

        if (needsFallback) {
            boolean fallbackEnabled = fallbackIsL2 ? sEnableL2 : sEnableDTW;
            boolean fallbackStrict = fallbackIsL2 ? sStrictSandboxL2 : sStrictSandboxDTW;

            if (fallbackEnabled && !fallbackStrict) {
                Log.i(TAG, "Primary confidence below threshold. Triggering Fallback.");
                RankResult fallbackResult;
                if (fallbackIsL2) {
                    fallbackResult = rankL2(inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet, sScopeL2, false);
                } else {
                    fallbackResult = rankDTW(inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet, sScopeDTW, false);
                }
                return mergeResults(primaryResult, fallbackResult, maxResults);
            }
        }

        return primaryResult.results;
    }

    // ─── Deep Search Logic ──────────────────────────────────────────────────

    private static SuggestionResults runDeepSearch(
            float[] inputVec, float inputLength, float[][] charToPos,
            Keyboard keyboard, InputPointers pointers, int maxResults, java.util.Set<String> predictionSet
    ) {
        List<RankResult> resultsList = new ArrayList<>();

        if (sEnableL2 && sParticipateDeepL2) {
            resultsList.add(rankL2(inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet, SCOPE_FULL, true));
        }
        if (sEnableDTW && sParticipateDeepDTW) {
            resultsList.add(rankDTW(inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet, SCOPE_FULL, true));
        }

        if (resultsList.isEmpty()) return new SuggestionResults(1, false, false);

        SuggestionResults merged = resultsList.get(0).results;
        for (int i = 1; i < resultsList.size(); i++) {
            merged = mergeResults(new RankResult(merged, 0f), resultsList.get(i), maxResults);
        }
        return merged;
    }

    // ─── L2 Ranking Function ────────────────────────────────────────────────

    private static RankResult rankL2(
            float[] inputVec, float inputLength, float[][] charToPos,
            Keyboard keyboard, InputPointers pointers, int maxResults,
            java.util.Set<String> predictionSet, String scope, boolean forceFull
    ) {
        List<Character> startLetters = nearestLettersFromMap(inputVec[0], inputVec[1], charToPos);
        List<Character> endLetters = nearestLettersFromMap(inputVec[2 * (inputVec.length / 2 - 1)], inputVec[2 * (inputVec.length / 2 - 1) + 1], charToPos);

        List<IndexEntry> candidates = new ArrayList<>();
        boolean searchSandbox = scope.equals(SCOPE_SANDBOX) || scope.equals(SCOPE_SANDBOX_FIRST) || forceFull;
        boolean searchFull = scope.equals(SCOPE_FULL) || scope.equals(SCOPE_SANDBOX_FIRST) || forceFull;

        if (searchSandbox && sSandboxIndex != null) {
            for (char first : startLetters) {
                List<IndexEntry> list = sSandboxIndex.byFirst.get(first);
                if (list != null) candidates.addAll(list);
            }
        }
        if (searchFull && sFullIndex != null) {
            for (char first : startLetters) {
                List<IndexEntry> list = sFullIndex.byFirst.get(first);
                if (list != null) candidates.addAll(list);
            }
        }

        if (candidates.isEmpty()) return new RankResult(new SuggestionResults(1, false, false), -Float.MAX_VALUE);

        // Filter by end letter
        List<IndexEntry> filtered = new ArrayList<>();
        for (IndexEntry e : candidates) {
            String lower = e.word;
            if (!lower.isEmpty() && endLetters.contains(lower.charAt(lower.length() - 1))) {
                filtered.add(e);
            }
        }
        if (filtered.isEmpty()) filtered = candidates;

        // Deduplicate (main dict may override sandbox) - keep higher frequency
        Map<String, IndexEntry> dedup = new HashMap<>();
        for (IndexEntry e : filtered) {
            IndexEntry existing = dedup.get(e.word);
            if (existing == null || e.frequency > existing.frequency) {
                dedup.put(e.word, e);
            }
        }
        filtered = new ArrayList<>(dedup.values());

        // Node filter (optional)
        String nodeSignature = extractNodeSignature(inputVec, inputVec.length / 2, charToPos);
        if (!nodeSignature.isEmpty()) {
            filtered = lcsFilter(filtered, nodeSignature);
        }

        return rankCoreL2(filtered, inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet, nodeSignature);
    }

    // ─── DTW Ranking Function ───────────────────────────────────────────────

    private static RankResult rankDTW(
            float[] inputVec, float inputLength, float[][] charToPos,
            Keyboard keyboard, InputPointers pointers, int maxResults,
            java.util.Set<String> predictionSet, String scope, boolean forceFull
    ) {
        List<Character> startLetters = nearestLettersFromMap(inputVec[0], inputVec[1], charToPos);
        List<Character> endLetters = nearestLettersFromMap(inputVec[2 * (inputVec.length / 2 - 1)], inputVec[2 * (inputVec.length / 2 - 1) + 1], charToPos);

        List<IndexEntry> candidates = new ArrayList<>();
        boolean searchSandbox = scope.equals(SCOPE_SANDBOX) || scope.equals(SCOPE_SANDBOX_FIRST) || forceFull;
        boolean searchFull = scope.equals(SCOPE_FULL) || scope.equals(SCOPE_SANDBOX_FIRST) || forceFull;

        if (searchSandbox && sSandboxIndex != null) {
            for (char first : startLetters) {
                List<IndexEntry> list = sSandboxIndex.byFirst.get(first);
                if (list != null) candidates.addAll(list);
            }
        }
        if (searchFull && sFullIndex != null) {
            for (char first : startLetters) {
                List<IndexEntry> list = sFullIndex.byFirst.get(first);
                if (list != null) candidates.addAll(list);
            }
        }

        if (candidates.isEmpty()) return new RankResult(new SuggestionResults(1, false, false), -Float.MAX_VALUE);

        List<IndexEntry> filtered = new ArrayList<>();
        for (IndexEntry e : candidates) {
            String lower = e.word;
            if (!lower.isEmpty() && endLetters.contains(lower.charAt(lower.length() - 1))) {
                filtered.add(e);
            }
        }
        if (filtered.isEmpty()) filtered = candidates;

        Map<String, IndexEntry> dedup = new HashMap<>();
        for (IndexEntry e : filtered) {
            IndexEntry existing = dedup.get(e.word);
            if (existing == null || e.frequency > existing.frequency) {
                dedup.put(e.word, e);
            }
        }
        filtered = new ArrayList<>(dedup.values());

        String nodeSignature = extractNodeSignature(inputVec, inputVec.length / 2, charToPos);
        if (!nodeSignature.isEmpty()) {
            filtered = lcsFilter(filtered, nodeSignature);
        }

        return rankCoreDTW(filtered, inputVec, inputLength, charToPos, keyboard, pointers, maxResults, predictionSet);
    }

    // ─── L2 Core Scoring ────────────────────────────────────────────────────

    private static RankResult rankCoreL2(
            List<IndexEntry> candidates,
            float[] inputVec, float inputLength,
            float[][] charToPos,
            Keyboard keyboard,
            InputPointers pointers,
            int maxResults,
            java.util.Set<String> predictionSet,
            String nodeSignature
    ) {
        Character loopLetter = detectDoubleLetterLoop(pointers, charToPos, keyboard);
        Character wiggleLetter = detectWiggledLetter(pointers, charToPos, keyboard);
        Character dwellLetter = detectDwelledLetter(pointers, keyboard, charToPos);

        int m = candidates.size();
        float[] scores = new float[m];
        int[] order = new int[m];
        float[] topScores = new float[maxResults];
        Arrays.fill(topScores, -Float.MAX_VALUE);
        float threshold = -Float.MAX_VALUE;

        for (int i = 0; i < m; i++) {
            IndexEntry e = candidates.get(i);
            String lower = e.word;

            float maxL2 = (threshold == -Float.MAX_VALUE) ? Float.MAX_VALUE : (e.freqBonus - threshold);
            float distance;
            if (maxL2 <= 0f) {
                distance = Float.MAX_VALUE;
            } else {
                distance = l2(inputVec, e.path, maxL2);
            }

            float bonuses = e.freqBonus;
            if (predictionSet != null && predictionSet.contains(lower)) bonuses += 0.15f;
            bonuses -= Math.abs(inputLength - e.pathLen) * 0.4f;

            Integer ub = sUserBoost.get(lower);
            if (ub != null) bonuses += sUserBoostCache[ub];

            if (sPrevWord1 != null && sPrevWord2 != null && sGestureDict != null) {
                int triFreq = sGestureDict.getTrigramFrequency(sPrevWord1, sPrevWord2, lower);
                if (triFreq > 0) bonuses += (float)(Math.log(triFreq + 1) * TRIGRAM_WEIGHT);
            }

            if (loopLetter != null && lower.contains("" + loopLetter + loopLetter)) bonuses += LOOP_BONUS;
            if (wiggleLetter != null && lower.indexOf(wiggleLetter) >= 0) bonuses += WIGGLE_BONUS;
            if (dwellLetter != null) {
                if (lower.indexOf(dwellLetter) >= 0) bonuses += DWELL_BONUS;
                if (lower.contains("" + dwellLetter + dwellLetter)) bonuses += DWELL_BONUS * 0.75f;
            }

            float score = -distance + bonuses;
            scores[i] = score;
            order[i] = i;
            if (score > threshold) {
                threshold = updateThreshold(topScores, score);
            }
        }

        for (int i = 1; i < m; i++) {
            int key = order[i];
            float ks = scores[key];
            int j = i - 1;
            while (j >= 0 && scores[order[j]] < ks) {
                order[j + 1] = order[j];
                j--;
            }
            order[j + 1] = key;
        }

        int take = Math.min(maxResults, m);
        SuggestionResults result = new SuggestionResults(take, false, false);
        int baseScore = 1_000_000;
        for (int rank = 0; rank < take; rank++) {
            IndexEntry e = candidates.get(order[rank]);
            String displayWord = e.word;
            if (sShowEngineId) displayWord += " L2";
            result.add(new SuggestedWordInfo(
                    displayWord, "",
                    baseScore - rank * 1000,
                    SuggestedWordInfo.KIND_CORRECTION,
                    Dictionary.DICTIONARY_USER_TYPED,
                    SuggestedWordInfo.NOT_AN_INDEX,
                    SuggestedWordInfo.NOT_A_CONFIDENCE
            ));
        }
        return new RankResult(result, scores[order[0]]);
    }

    // ─── DTW Core Scoring ───────────────────────────────────────────────────

    private static RankResult rankCoreDTW(
            List<IndexEntry> candidates,
            float[] inputVec, float inputLength,
            float[][] charToPos,
            Keyboard keyboard,
            InputPointers pointers,
            int maxResults,
            java.util.Set<String> predictionSet
    ) {
        Character loopLetter = detectDoubleLetterLoop(pointers, charToPos, keyboard);
        Character wiggleLetter = detectWiggledLetter(pointers, charToPos, keyboard);
        Character dwellLetter = detectDwelledLetter(pointers, keyboard, charToPos);

        int m = candidates.size();
        float[] scores = new float[m];
        int[] order = new int[m];

        for (int i = 0; i < m; i++) {
            IndexEntry e = candidates.get(i);
            String lower = e.word;

            float dtwSq = dtwDistanceSq(inputVec, e.path);
            float distance = (float) Math.sqrt(dtwSq);

            float bonuses = e.freqBonus;
            if (predictionSet != null && predictionSet.contains(lower)) bonuses += 0.15f;
            bonuses -= Math.abs(inputLength - e.pathLen) * 0.4f;

            Integer ub = sUserBoost.get(lower);
            if (ub != null) bonuses += sUserBoostCache[ub];

            if (sPrevWord1 != null && sPrevWord2 != null && sGestureDict != null) {
                int triFreq = sGestureDict.getTrigramFrequency(sPrevWord1, sPrevWord2, lower);
                if (triFreq > 0) bonuses += (float)(Math.log(triFreq + 1) * TRIGRAM_WEIGHT);
            }

            if (loopLetter != null && lower.contains("" + loopLetter + loopLetter)) bonuses += LOOP_BONUS;
            if (wiggleLetter != null && lower.indexOf(wiggleLetter) >= 0) bonuses += WIGGLE_BONUS;
            if (dwellLetter != null) {
                if (lower.indexOf(dwellLetter) >= 0) bonuses += DWELL_BONUS;
                if (lower.contains("" + dwellLetter + dwellLetter)) bonuses += DWELL_BONUS * 0.75f;
            }

            float score = -distance + bonuses;
            scores[i] = score;
            order[i] = i;
        }

        for (int i = 1; i < m; i++) {
            int key = order[i];
            float ks = scores[key];
            int j = i - 1;
            while (j >= 0 && scores[order[j]] < ks) {
                order[j + 1] = order[j];
                j--;
            }
            order[j + 1] = key;
        }

        int take = Math.min(maxResults, m);
        SuggestionResults result = new SuggestionResults(take, false, false);
        int baseScore = 1_000_000;
        for (int rank = 0; rank < take; rank++) {
            IndexEntry e = candidates.get(order[rank]);
            String displayWord = e.word;
            if (sShowEngineId) displayWord += " DTW";
            result.add(new SuggestedWordInfo(
                    displayWord, "",
                    baseScore - rank * 1000,
                    SuggestedWordInfo.KIND_CORRECTION,
                    Dictionary.DICTIONARY_USER_TYPED,
                    SuggestedWordInfo.NOT_AN_INDEX,
                    SuggestedWordInfo.NOT_A_CONFIDENCE
            ));
        }
        return new RankResult(result, scores[order[0]]);
    }

    // ─── Merge Results ──────────────────────────────────────────────────────

    private static SuggestionResults mergeResults(RankResult r1, RankResult r2, int maxResults) {
        // Simple merge: return the one with higher bestScore. We'll improve later.
        return (r1.bestScore >= r2.bestScore) ? r1.results : r2.results;
    }

    // ─── Manual Deep Search Trigger (public) ──────────────────────────────

    public static void requestManualDeepSearch() {
        sManualDeepSearchRequested = true;
        Log.i(TAG, "Manual deep search requested. Next gesture will trigger full search.");
    }

    // ─── Gesture Hints ──────────────────────────────────────────────────────

    private static Character detectDoubleLetterLoop(InputPointers pointers, float[][] charToPos, Keyboard keyboard) {
        int n = pointers.getPointerSize();
        if (n < 4) return null;
        int[] xs = pointers.getXCoordinates();
        int[] ys = pointers.getYCoordinates();
        float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;

        for (int i = 0; i < n - 2; i++) {
            for (int j = i + 2; j < n - 1; j++) {
                float x1 = xs[i], y1 = ys[i];
                float x2 = xs[i + 1], y2 = ys[i + 1];
                float x3 = xs[j], y3 = ys[j];
                float x4 = xs[j + 1], y4 = ys[j + 1];

                float d = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
                if (Math.abs(d) < 1e-6f) continue;

                float t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / d;
                float u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / d;

                if (t >= 0f && t <= 1f && u >= 0f && u <= 1f) {
                    float ix = x1 + t * (x2 - x1);
                    float iy = y1 + t * (y2 - y1);
                    List<Character> nearest = nearestLettersFromMap(ix / kw, iy / kh, charToPos);
                    if (!nearest.isEmpty()) return nearest.get(0);
                }
            }
        }
        return null;
    }

    private static Character detectWiggledLetter(InputPointers pointers, float[][] charToPos, Keyboard keyboard) {
        int n = pointers.getPointerSize();
        if (n < 5) return null;
        int[] xs = pointers.getXCoordinates();
        int[] ys = pointers.getYCoordinates();
        float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;

        for (int i = 1; i < n - 2; i++) {
            float v1x = xs[i] - xs[i - 1];
            float v1y = ys[i] - ys[i - 1];
            float v2x = xs[i + 1] - xs[i];
            float v2y = ys[i + 1] - ys[i];

            float dot = v1x * v2x + v1y * v2y;
            float len1Sq = v1x * v1x + v1y * v1y;
            float len2Sq = v2x * v2x + v2y * v2y;

            float thresholdDot = -0.5f + 0.4f;
            float chordRatioThreshold = 0.3f + 0.4f;

            if (dot < thresholdDot * (float) Math.sqrt(len1Sq * len2Sq)) {
                float chordX = xs[i + 1] - xs[i - 1];
                float chordY = ys[i + 1] - ys[i - 1];
                float chordSq = chordX * chordX + chordY * chordY;
                float totalLen = (float) (Math.sqrt(len1Sq) + Math.sqrt(len2Sq));
                if (chordSq < totalLen * totalLen * chordRatioThreshold) {
                    List<Character> nearest = nearestLettersFromMap(xs[i] / kw, ys[i] / kh, charToPos);
                    if (!nearest.isEmpty()) return nearest.get(0);
                }
            }
        }
        return null;
    }

    private static Character detectDwelledLetter(InputPointers pointers, Keyboard keyboard, float[][] charToPos) {
        int n = pointers.getPointerSize();
        if (n < 3) return null;
        int[] xs = pointers.getXCoordinates();
        int[] ys = pointers.getYCoordinates();
        int[] times = pointers.getTimes();
        float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;

        boolean useEstimates = (times == null);
        char currentKey = 0;
        int dwellStartIdx = 0;

        for (int i = 0; i < n; i++) {
            float nx = xs[i] / kw;
            float ny = ys[i] / kh;
            char key = getNearestKey(nx, ny, charToPos);
            if (key < 'a' || key > 'z') continue;

            float dx = charToPos[key - 'a'][0] - nx;
            float dy = charToPos[key - 'a'][1] - ny;
            float distSq = dx * dx + dy * dy;

            if (key == currentKey && distSq <= DWELL_RADIUS_SQ) {
                int elapsed;
                if (useEstimates) {
                    elapsed = (i - dwellStartIdx) * 10;
                } else {
                    elapsed = times[i] - times[dwellStartIdx];
                }
                float moveDist = 0;
                if (i > dwellStartIdx) {
                    float sx = xs[dwellStartIdx] / kw;
                    float sy = ys[dwellStartIdx] / kh;
                    moveDist = (float) Math.sqrt((nx - sx) * (nx - sx) + (ny - sy) * (ny - sy));
                }
                float speed = (elapsed > 0) ? moveDist / elapsed : 0;
                if (elapsed >= DWELL_DURATION_MS && speed < DWELL_SPEED_THRESHOLD) {
                    return currentKey;
                }
            } else {
                currentKey = key;
                dwellStartIdx = i;
            }
        }
        return null;
    }

    // ─── LCS Filter ─────────────────────────────────────────────────────────

    private static List<IndexEntry> lcsFilter(List<IndexEntry> candidates, String nodeSignature) {
        if (nodeSignature.isEmpty()) return candidates;
        List<IndexEntry> filtered = new ArrayList<>();
        int minMatch = Math.max(1, (int) Math.ceil(0.75 * nodeSignature.length()));
        for (IndexEntry e : candidates) {
            String wordSeq = canonicalNodeSeq(e.word);
            if (longestCommonSubsequence(nodeSignature, wordSeq) >= minMatch) {
                filtered.add(e);
            }
        }
        return filtered.isEmpty() ? candidates : filtered;
    }

    private static int longestCommonSubsequence(String a, String b) {
        int m = a.length(), n = b.length();
        int[] dp = new int[n + 1];
        for (int i = 1; i <= m; i++) {
            int prev = 0;
            for (int j = 1; j <= n; j++) {
                int temp = dp[j];
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    dp[j] = prev + 1;
                } else {
                    dp[j] = Math.max(dp[j], dp[j - 1]);
                }
                prev = temp;
            }
        }
        return dp[n];
    }

    private static String canonicalNodeSeq(String word) {
        StringBuilder sb = new StringBuilder();
        char prev = 0;
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (c >= 'a' && c <= 'z' && c != prev) {
                sb.append(c);
                prev = c;
            }
        }
        return sb.toString();
    }

    // ─── Node Extraction ───────────────────────────────────────────────────

    private static String extractNodeSignature(float[] rawFlat, int numPoints, float[][] charToPos) {
        if (numPoints < 2) return "";
        StringBuilder sb = new StringBuilder();
        float[] vecX = new float[numPoints - 1];
        float[] vecY = new float[numPoints - 1];
        for (int i = 0; i < numPoints - 1; i++) {
            vecX[i] = rawFlat[2 * (i + 1)] - rawFlat[2 * i];
            vecY[i] = rawFlat[2 * (i + 1) + 1] - rawFlat[2 * i + 1];
        }

        char lastKey = 0;
        char startKey = getNearestKey(rawFlat[0], rawFlat[1], charToPos);
        if (startKey >= 'a' && startKey <= 'z') {
            sb.append(startKey);
            lastKey = startKey;
        }

        for (int i = 1; i < numPoints - 2; i++) {
            float v1x = vecX[i - 1];
            float v1y = vecY[i - 1];
            float v2x = vecX[i];
            float v2y = vecY[i];

            float len1Sq = v1x * v1x + v1y * v1y;
            float len2Sq = v2x * v2x + v2y * v2y;
            if (len1Sq == 0 || len2Sq == 0) continue;

            float dot = v1x * v2x + v1y * v2y;
            float cross = v1x * v2y - v1y * v2x;
            float angle = (float) Math.toDegrees(Math.atan2(Math.abs(cross), dot));
            if (angle >= 45f) {
                char key = getNearestKey(rawFlat[2 * i], rawFlat[2 * i + 1], charToPos);
                if (key >= 'a' && key <= 'z' && key != lastKey) {
                    sb.append(key);
                    lastKey = key;
                }
            }
        }

        char endKey = getNearestKey(rawFlat[2 * (numPoints - 1)], rawFlat[2 * (numPoints - 1) + 1], charToPos);
        if (endKey >= 'a' && endKey <= 'z' && endKey != lastKey) {
            sb.append(endKey);
        }
        return sb.toString();
    }

    private static char getNearestKey(float x, float y, float[][] charToPos) {
        float minDist = Float.MAX_VALUE;
        char best = 0;
        for (int i = 0; i < 26; i++) {
            float cx = charToPos[i][0], cy = charToPos[i][1];
            if (cx == 0f && cy == 0f) continue;
            float d = (x - cx) * (x - cx) + (y - cy) * (y - cy);
            if (d < minDist) {
                minDist = d;
                best = (char) ('a' + i);
            }
        }
        return best;
    }

    // ─── Math Helpers ──────────────────────────────────────────────────────

    private static float dtwDistanceSq(float[] path1, float[] path2) {
        int len = N_PTS;
        float[] cost = new float[len * len];
        float infinity = Float.MAX_VALUE;

        for (int i = 0; i < len; i++) {
            for (int j = Math.max(0, i - DTW_BAND); j <= Math.min(len - 1, i + DTW_BAND); j++) {
                float dx = path1[2 * i] - path2[2 * j];
                float dy = path1[2 * i + 1] - path2[2 * j + 1];
                float dist = dx * dx + dy * dy;
                float minPrev;
                if (i == 0 && j == 0) {
                    minPrev = 0;
                } else {
                    minPrev = infinity;
                    if (i > 0 && j >= i - DTW_BAND) minPrev = Math.min(minPrev, cost[(i - 1) * len + j]);
                    if (j > 0 && i >= j - DTW_BAND) minPrev = Math.min(minPrev, cost[i * len + (j - 1)]);
                    if (i > 0 && j > 0) minPrev = Math.min(minPrev, cost[(i - 1) * len + (j - 1)]);
                }
                cost[i * len + j] = dist + minPrev;
            }
        }
        return cost[(len - 1) * len + (len - 1)];
    }

    private static float l2(float[] a, float[] b, float maxL2) {
        float s = 0;
        int n = a.length / 2;
        float limitSq = maxL2 * maxL2;
        for (int i = 0; i < n; i++) {
            float dx = a[2 * i] - b[2 * i];
            float dy = a[2 * i + 1] - b[2 * i + 1];
            float distSq = dx * dx + dy * dy;
            if (i == 0 || i == n - 1) s += distSq * 2.0f;
            else s += distSq;
            if (s > limitSq) return Float.MAX_VALUE;
        }
        return (float) Math.sqrt(s);
    }

    private static float updateThreshold(float[] topScores, float newScore) {
        int minIdx = 0;
        for (int i = 1; i < topScores.length; i++) {
            if (topScores[i] < topScores[minIdx]) minIdx = i;
        }
        if (newScore > topScores[minIdx]) {
            topScores[minIdx] = newScore;
        }
        float min = topScores[0];
        for (int i = 1; i < topScores.length; i++) {
            if (topScores[i] < min) min = topScores[i];
        }
        return min;
    }

    // ─── Utilities ──────────────────────────────────────────────────────────

    private static List<Character> nearestLettersFromMap(float nx, float ny, float[][] charToPos) {
        float minDist = Float.MAX_VALUE;
        float[] dists = new float[26];
        for (int i = 0; i < 26; i++) {
            float cx = charToPos[i][0], cy = charToPos[i][1];
            if (cx == 0f && cy == 0f) { dists[i] = Float.MAX_VALUE; continue; }
            float d = (nx - cx) * (nx - cx) + (ny - cy) * (ny - cy);
            dists[i] = d;
            if (d < minDist) minDist = d;
        }
        List<Character> results = new ArrayList<>(4);
        float threshold = minDist + PROXIMITY_RADIUS;
        for (int i = 0; i < 26; i++) {
            if (dists[i] <= threshold) results.add((char) ('a' + i));
        }
        return results;
    }

    static float[][] buildCharToPos(Keyboard keyboard) {
        float[][] map = new float[26][2];
        float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;
        for (Key key : keyboard.getSortedKeys()) {
            int code = key.getCode();
            if (!isAsciiLetter(code)) continue;
            int idx = Character.toLowerCase((char) code) - 'a';
            Rect hitBox = key.getHitBox();
            map[idx][0] = hitBox.exactCenterX() / kw;
            map[idx][1] = hitBox.exactCenterY() / kh;
        }
        return map;
    }

    static float[] wordPath(String word, float[][] charToPos) {
        List<float[]> pts = new ArrayList<>();
        float lastX = -1f, lastY = -1f;
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            int idx = c - 'a';
            if (idx < 0 || idx >= 26) continue;
            float[] p = charToPos[idx];
            if (pts.isEmpty() || p[0] != lastX || p[1] != lastY) {
                pts.add(new float[]{p[0], p[1]});
                lastX = p[0]; lastY = p[1];
            }
        }
        if (pts.size() < 2) {
            float[] r = new float[N_PTS * 2];
            float x = pts.get(0)[0], y = pts.get(0)[1];
            for (int i = 0; i < N_PTS; i++) { r[2 * i] = x; r[2 * i + 1] = y; }
            return r;
        }
        return generateCatmullRom(pts, N_PTS);
    }

    private static float[] generateCatmullRom(List<float[]> pts, int n) {
        int m = pts.size();
        if (m < 2) {
            float[] r = new float[n * 2];
            float x = pts.get(0)[0], y = pts.get(0)[1];
            for (int i = 0; i < n; i++) { r[2 * i] = x; r[2 * i + 1] = y; }
            return r;
        }

        float[] cum = new float[m];
        cum[0] = 0;
        for (int i = 1; i < m; i++) {
            float dx = pts.get(i)[0] - pts.get(i - 1)[0];
            float dy = pts.get(i)[1] - pts.get(i - 1)[1];
            cum[i] = cum[i - 1] + (float) Math.sqrt(dx * dx + dy * dy);
        }
        float total = cum[m - 1];
        if (total < 1e-9f) {
            float[] r = new float[n * 2];
            float x = pts.get(0)[0], y = pts.get(0)[1];
            for (int i = 0; i < n; i++) { r[2 * i] = x; r[2 * i + 1] = y; }
            return r;
        }

        float[] result = new float[n * 2];
        for (int i = 0; i < n; i++) {
            float t = total * i / (n - 1);
            int seg = 0;
            while (seg < m - 1 && cum[seg + 1] < t) seg++;
            float u = (t - cum[seg]) / (cum[seg + 1] - cum[seg]);

            if (seg == 0) {
                result[2 * i] = pts.get(0)[0] + u * (pts.get(1)[0] - pts.get(0)[0]);
                result[2 * i + 1] = pts.get(0)[1] + u * (pts.get(1)[1] - pts.get(0)[1]);
            } else if (seg == m - 2) {
                result[2 * i] = pts.get(m - 2)[0] + u * (pts.get(m - 1)[0] - pts.get(m - 2)[0]);
                result[2 * i + 1] = pts.get(m - 2)[1] + u * (pts.get(m - 1)[1] - pts.get(m - 2)[1]);
            } else {
                float[] p0 = pts.get(seg - 1);
                float[] p1 = pts.get(seg);
                float[] p2 = pts.get(seg + 1);
                float[] p3 = pts.get(seg + 2);
                float u2 = u * u;
                float u3 = u2 * u;
                float x = 0.5f * ((2 * p1[0]) +
                        (-p0[0] + p2[0]) * u +
                        (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * u2 +
                        (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * u3);
                float y = 0.5f * ((2 * p1[1]) +
                        (-p0[1] + p2[1]) * u +
                        (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * u2 +
                        (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * u3);
                result[2 * i] = x;
                result[2 * i + 1] = y;
            }
        }
        return result;
    }

    static float[] resampleFlat(float[] pts, int numPts, int n) {
        if (numPts == 0) return new float[n * 2];
        if (numPts == 1) {
            float[] r = new float[n * 2];
            float x = pts[0], y = pts[1];
            for (int i = 0; i < n; i++) { r[2 * i] = x; r[2 * i + 1] = y; }
            return r;
        }
        float[] cum = new float[numPts];
        for (int i = 1; i < numPts; i++) {
            float dx = pts[2 * i] - pts[2 * (i - 1)];
            float dy = pts[2 * i + 1] - pts[2 * (i - 1) + 1];
            cum[i] = cum[i - 1] + (float) Math.sqrt(dx * dx + dy * dy);
        }
        float total = cum[numPts - 1];
        if (total < 1e-9f) {
            float[] r = new float[n * 2];
            float x = pts[0], y = pts[1];
            for (int i = 0; i < n; i++) { r[2 * i] = x; r[2 * i + 1] = y; }
            return r;
        }
        float[] result = new float[n * 2];
        int seg = 0;
        for (int i = 0; i < n; i++) {
            float t = total * i / (n - 1);
            while (seg < numPts - 2 && cum[seg + 1] < t) seg++;
            float segLen = cum[seg + 1] - cum[seg];
            float alpha = (segLen > 1e-9f) ? (t - cum[seg]) / segLen : 0f;
            result[2 * i] = pts[2 * seg] + alpha * (pts[2 * (seg + 1)] - pts[2 * seg]);
            result[2 * i + 1] = pts[2 * seg + 1] + alpha * (pts[2 * (seg + 1) + 1] - pts[2 * seg + 1]);
        }
        return result;
    }

    private static float pathLength(float[] path) {
        float len = 0;
        int n = path.length / 2;
        for (int i = 0; i < n - 1; i++) {
            float dx = path[2 * (i + 1)] - path[2 * i];
            float dy = path[2 * (i + 1) + 1] - path[2 * i + 1];
            len += (float) Math.sqrt(dx * dx + dy * dy);
        }
        return len;
    }

    private static boolean isAsciiLetter(int code) {
        return (code >= 'a' && code <= 'z') || (code >= 'A' && code <= 'Z');
    }

    public static int layoutFingerprint(Keyboard keyboard) {
        return Arrays.deepHashCode(buildCharToPos(keyboard));
    }

    // ─── Learning ───────────────────────────────────────────────────────────

    public static void recordAccepted(String word, InputPointers pointers, Keyboard keyboard, GestureIndex activeIndex) {
        if (mIncognito || word == null || word.isEmpty()) return;
        String lower = word.toLowerCase(Locale.ROOT);
        float[] path = null;
        if (pointers != null && pointers.getPointerSize() >= 2 && keyboard != null) {
            int n = pointers.getPointerSize();
            int[] xs = pointers.getXCoordinates();
            int[] ys = pointers.getYCoordinates();
            float kw = keyboard.mOccupiedWidth, kh = keyboard.mOccupiedHeight;
            float[] rawFlat = new float[n * 2];
            for (int i = 0; i < n; i++) {
                rawFlat[2 * i] = xs[i] / kw;
                rawFlat[2 * i + 1] = ys[i] / kh;
            }
            path = resampleFlat(rawFlat, n, N_PTS);
        }
        sUserBoost.merge(lower, 1, (a, b) -> Math.min(a + b, 50));

        synchronized (sHoldingPen) {
            GestureEvent ev = new GestureEvent();
            ev.word = lower;
            ev.path = path;
            sHoldingPen.add(ev);
        }
        Log.i(TAG, "recordAccepted: " + lower + " added to holding pen");
    }

    public static void onKeyboardClose() {
        if (mIncognito) return;
        List<GestureEvent> eventsToProcess;
        synchronized (sHoldingPen) {
            eventsToProcess = new ArrayList<>(sHoldingPen);
            sHoldingPen.clear();
        }
        if (sGestureDict == null) return;

        String prev1 = sPrevWord1;
        String prev2 = sPrevWord2;

        for (GestureEvent ev : eventsToProcess) {
            if (ev.word == null || ev.word.length() < 2) continue;
            sGestureDict.addOrUpdateWord(ev.word, ev.path, 1);
            if (prev1 != null && prev2 != null) {
                sGestureDict.updateTrigram(prev1, prev2, ev.word);
                prev1 = prev2;
                prev2 = ev.word;
            }
        }
        sGestureDict.save(sDictFile);
        Log.i(TAG, "onKeyboardClose: saved " + eventsToProcess.size() + " events");
    }

    // ─── Sync (Seeding on empty start) ────────────────────────────────────

    public static void syncUserHistory(helium314.keyboard.latin.DictionaryFacilitator facilitator) {
        if (sGestureDict == null || sAppContext == null) return;
        if (!sGestureDict.getEntries().isEmpty()) return;

        Log.i(TAG, "syncUserHistory: seeding from user dictionary and history");

        try {
            ContentResolver cr = sAppContext.getContentResolver();
            Cursor cursor = cr.query(
                    UserDictionary.Words.CONTENT_URI,
                    new String[]{UserDictionary.Words.WORD},
                    UserDictionary.Words.LOCALE + " = ? OR " + UserDictionary.Words.LOCALE + " IS NULL",
                    new String[]{Locale.getDefault().toString()},
                    null
            );
            if (cursor != null) {
                int wordIndex = cursor.getColumnIndex(UserDictionary.Words.WORD);
                while (cursor.moveToNext()) {
                    String word = cursor.getString(wordIndex);
                    if (word != null && word.length() >= 2) {
                        String lower = word.toLowerCase(Locale.ROOT);
                        if (facilitator.isBlacklisted(lower)) continue;
                        sGestureDict.addOrUpdateWord(lower, null, 10);
                    }
                }
                cursor.close();
            }
        } catch (Exception ignored) {}

        facilitator.forEachUserHistoryWord((word, freq) -> {
            if (word == null || word.length() < 2) return;
            String lower = word.toLowerCase(Locale.ROOT);
            if (facilitator.isBlacklisted(lower)) return;
            int historyFreq = (freq != null) ? freq : 1;
            sGestureDict.addOrUpdateWord(lower, null, historyFreq);
        });

        sGestureDict.save(sDictFile);
        Log.i(TAG, "syncUserHistory: seeded " + sGestureDict.getEntries().size() + " words");
    }

    // ─── Stubs ──────────────────────────────────────────────────────────────

    public static void onWordTapped(String word, helium314.keyboard.latin.DictionaryFacilitator f) {
        if (mIncognito || word == null || word.isEmpty()) return;
        String lower = word.toLowerCase(Locale.ROOT);
        if (f.isBlacklisted(lower)) return;
        sGestureDict.addOrUpdateWord(lower, null, 1);
        Log.i(TAG, "onWordTapped: " + lower + " added to gesture dictionary (frequency +1)");
    }
    public static void markLastGestureBackspaced() {}
    public static List<String> getGestureCandidates(String word) { return Collections.emptyList(); }
    public static void onSuggestionPicked(String originalWord, String newWord) {}
    public static boolean hasLoopAtEnd(InputPointers pointers, Keyboard keyboard) { return false; }
    public static boolean isSequenceMatch(String word, float[] path, float[][] charToPos) { return false; }
    public static List<Character> nearestLetters(int x, int y, Keyboard keyboard) { return new ArrayList<>(); }

    // ─── Constants for hints ──────────────────────────────────────────────
    private static final float DWELL_RADIUS_SQ = 0.01f;
    private static final float DWELL_SPEED_THRESHOLD = 0.5f;
    private static final int DWELL_DURATION_MS = 80;
    private static final float LOOP_BONUS = 0.35f;
    private static final float WIGGLE_BONUS = 0.25f;
    private static final float DWELL_BONUS = 0.2f;
    private static final float TRIGRAM_WEIGHT = 0.12f;

    // ─── Permanent Gesture Dictionary ──────────────────────────────────────

    public static class WordEntry {
        public final String word;
        public int frequency;
        private float[] path;

        public WordEntry(String w, float[] p, int f) {
            this.word = w;
            this.frequency = f;
            if (p != null && p.length == N_PTS * 2) path = p.clone();
        }

        public float[] path() { return path; }
        public void setPath(float[] p) { if (p != null && p.length == N_PTS * 2) path = p.clone(); }
    }

    private static class GestureDictionary {
        private final Map<String, WordEntry> entries = new HashMap<>();
        private final Map<Long, Map<String, Integer>> trigrams = new HashMap<>();

        public void addOrUpdateWord(String word, float[] path, int freqIncrement) {
            WordEntry entry = entries.get(word);
            if (entry == null) {
                if (freqIncrement <= 0) return;
                entry = new WordEntry(word, path, freqIncrement);
                entries.put(word, entry);
            } else {
                entry.frequency += freqIncrement;
                if (entry.frequency < 0) entry.frequency = 0;
                if (path != null && path.length == N_PTS * 2) entry.setPath(path);
            }
        }

        public boolean contains(String word) { return entries.containsKey(word); }
        public Collection<WordEntry> getEntries() { return entries.values(); }

        public void updateTrigram(String w1, String w2, String next) {
            long hash = ((long) w1.hashCode() * 31 + (long) w2.hashCode());
            Map<String, Integer> nextMap = trigrams.computeIfAbsent(hash, k -> new HashMap<>());
            nextMap.put(next, nextMap.getOrDefault(next, 0) + 1);
        }

        public int getTrigramFrequency(String w1, String w2, String next) {
            long hash = ((long) w1.hashCode() * 31 + (long) w2.hashCode());
            Map<String, Integer> nextMap = trigrams.get(hash);
            if (nextMap == null) return 0;
            return nextMap.getOrDefault(next, 0);
        }

        public void save(File file) {
            try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
                out.writeInt(3);
                out.writeInt(entries.size());
                for (WordEntry we : entries.values()) {
                    out.writeUTF(we.word);
                    out.writeInt(we.frequency);
                    boolean hasPath = (we.path != null && we.path.length == N_PTS * 2);
                    out.writeBoolean(hasPath);
                    if (hasPath) {
                        for (int i = 0; i < N_PTS * 2; i++) out.writeFloat(we.path[i]);
                    }
                }
                out.writeInt(trigrams.size());
                for (Map.Entry<Long, Map<String, Integer>> triEntry : trigrams.entrySet()) {
                    out.writeLong(triEntry.getKey());
                    Map<String, Integer> nextMap = triEntry.getValue();
                    out.writeInt(nextMap.size());
                    for (Map.Entry<String, Integer> next : nextMap.entrySet()) {
                        out.writeUTF(next.getKey());
                        out.writeInt(next.getValue());
                    }
                }
            } catch (IOException e) { Log.e(TAG, "Error saving dict", e); }
        }

        public void load(File file) {
            if (!file.exists()) return;
            entries.clear();
            trigrams.clear();
            try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
                int version = in.readInt();
                if (version < 1 || version > 3) return;
                int count = in.readInt();
                for (int i = 0; i < count; i++) {
                    String word = in.readUTF();
                    int freq = in.readInt();
                    boolean hasPath = in.readBoolean();
                    float[] path = null;
                    if (hasPath) {
                        path = new float[N_PTS * 2];
                        for (int j = 0; j < N_PTS * 2; j++) path[j] = in.readFloat();
                    }
                    entries.put(word, new WordEntry(word, path, freq));
                }
                if (version >= 3) {
                    int triCount = in.readInt();
                    for (int i = 0; i < triCount; i++) {
                        long hash = in.readLong();
                        int nextCount = in.readInt();
                        Map<String, Integer> nextMap = new HashMap<>();
                        for (int j = 0; j < nextCount; j++) {
                            String nextWord = in.readUTF();
                            int freq = in.readInt();
                            nextMap.put(nextWord, freq);
                        }
                        trigrams.put(hash, nextMap);
                    }
                }
            } catch (IOException e) { Log.e(TAG, "Error loading dict", e); }
        }
    }

    private static class GestureEvent {
        String word;
        float[] path;
    }
    }
