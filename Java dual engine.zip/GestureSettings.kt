// SPDX-License-Identifier: GPL-3.0-only
package helium314.keyboard.latin.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import helium314.keyboard.latin.utils.prefs

/**
 * Centralized gesture settings constants and helpers.
 * All preference keys used by the gesture engine and UI are defined here.
 */
object GestureSettings {

    // ─── Engine enable/disable ──────────────────────────────────────────────
    const val PREF_ENABLE_L2 = "gesture_enable_l2"
    const val PREF_ENABLE_DTW = "gesture_enable_dtw"
    const val DEFAULT_ENABLE_L2 = false
    const val DEFAULT_ENABLE_DTW = false

    // ─── Engine roles ──────────────────────────────────────────────────────
    const val PREF_PRIMARY_ENGINE = "gesture_primary_engine"
    const val PREF_FALLBACK_ENGINE = "gesture_fallback_engine"
    const val DEFAULT_PRIMARY_ENGINE = "dtw"
    const val DEFAULT_FALLBACK_ENGINE = "l2"

    // ─── Parallel mode ─────────────────────────────────────────────────────
    const val PREF_PARALLEL_MODE = "gesture_parallel_mode"
    const val DEFAULT_PARALLEL_MODE = false

    // ─── Search scopes (per engine) ────────────────────────────────────────
    const val PREF_SCOPE_L2 = "gesture_search_scope_l2"
    const val PREF_SCOPE_DTW = "gesture_search_scope_dtw"
    const val DEFAULT_SCOPE_L2 = "sandbox_first"
    const val DEFAULT_SCOPE_DTW = "full"
    const val SCOPE_SANDBOX = "sandbox"
    const val SCOPE_FULL = "full"
    const val SCOPE_SANDBOX_FIRST = "sandbox_first"

    // ─── Confidence thresholds (per engine) ────────────────────────────────
    const val PREF_CONFIDENCE_L2 = "gesture_confidence_threshold_l2"
    const val PREF_CONFIDENCE_DTW = "gesture_confidence_threshold_dtw"
    const val DEFAULT_CONFIDENCE = -0.15f

    // ─── Strict sandbox mode (per engine) ──────────────────────────────────
    const val PREF_STRICT_SANDBOX_L2 = "gesture_strict_sandbox_l2"
    const val PREF_STRICT_SANDBOX_DTW = "gesture_strict_sandbox_dtw"
    const val DEFAULT_STRICT_SANDBOX = false

    // ─── Participate in manual deep search (per engine) ───────────────────
    const val PREF_PARTICIPATE_DEEP_L2 = "gesture_participate_deep_search_l2"
    const val PREF_PARTICIPATE_DEEP_DTW = "gesture_participate_deep_search_dtw"
    const val DEFAULT_PARTICIPATE_DEEP = true

    // ─── Manual deep search trigger ────────────────────────────────────────
    const val PREF_DEEP_SEARCH_TRIGGER = "gesture_deep_search_trigger"
    const val DEFAULT_DEEP_SEARCH_TRIGGER = "toolbar_key"
    const val TRIGGER_TOOLBAR_KEY = "toolbar_key"
    const val TRIGGER_GESTURE = "gesture"
    const val TRIGGER_NONE = "none"

    // ─── Show engine ID in suggestions ─────────────────────────────────────
    const val PREF_SHOW_ENGINE_ID = "gesture_show_engine_id"
    const val DEFAULT_SHOW_ENGINE_ID = false

    // ─── Sandbox size limit ────────────────────────────────────────────────
    const val PREF_SANDBOX_SIZE = "gesture_sandbox_size"
    const val DEFAULT_SANDBOX_SIZE = 5000

    // ─── Eviction policy ───────────────────────────────────────────────────
    const val PREF_EVICTION_POLICY = "gesture_eviction_policy"
    const val DEFAULT_EVICTION_POLICY = "least_used"
    const val EVICT_LEAST_USED = "least_used"
    const val EVICT_OLDEST = "oldest"
    const val EVICT_NONE = "none"

    // ─── Learning settings (reuse existing keys from Settings) ─────────────
    // These are already defined in Settings, but we reference them for clarity.
    // The actual keys are:
    // - Settings.PREF_GESTURE_LEARN_TAPPED_KNOWN
    // - Settings.PREF_GESTURE_LEARN_TAPPED_UNKNOWN
    // - Settings.PREF_GESTURE_SYNC_USER_DICT
    // - Settings.PREF_GESTURE_PATHS_PER_WORD
    // - Settings.PREF_GESTURE_TOLERANCE_BOOST
    // - Settings.PREF_GESTURE_OFFSET_COPIES
    // - Settings.PREF_GESTURE_DWELL_TIME
    // - Settings.PREF_GESTURE_WIGGLE_SENSITIVITY
    // - Settings.PREF_GESTURE_LOOP_SENSITIVITY

    // ─── Helper to load all gesture settings into a data class ─────────────
    data class Settings(
        val enableL2: Boolean,
        val enableDtw: Boolean,
        val primaryEngine: String,
        val fallbackEngine: String,
        val parallelMode: Boolean,
        val scopeL2: String,
        val scopeDtw: String,
        val confidenceL2: Float,
        val confidenceDtw: Float,
        val strictSandboxL2: Boolean,
        val strictSandboxDtw: Boolean,
        val participateDeepL2: Boolean,
        val participateDeepDtw: Boolean,
        val deepSearchTrigger: String,
        val showEngineId: Boolean,
        val sandboxSize: Int,
        val evictionPolicy: String,
    )

    fun loadSettings(context: Context): Settings {
        val prefs = context.prefs()
        return Settings(
            enableL2 = prefs.getBoolean(PREF_ENABLE_L2, DEFAULT_ENABLE_L2),
            enableDtw = prefs.getBoolean(PREF_ENABLE_DTW, DEFAULT_ENABLE_DTW),
            primaryEngine = prefs.getString(PREF_PRIMARY_ENGINE, DEFAULT_PRIMARY_ENGINE) ?: DEFAULT_PRIMARY_ENGINE,
            fallbackEngine = prefs.getString(PREF_FALLBACK_ENGINE, DEFAULT_FALLBACK_ENGINE) ?: DEFAULT_FALLBACK_ENGINE,
            parallelMode = prefs.getBoolean(PREF_PARALLEL_MODE, DEFAULT_PARALLEL_MODE),
            scopeL2 = prefs.getString(PREF_SCOPE_L2, DEFAULT_SCOPE_L2) ?: DEFAULT_SCOPE_L2,
            scopeDtw = prefs.getString(PREF_SCOPE_DTW, DEFAULT_SCOPE_DTW) ?: DEFAULT_SCOPE_DTW,
            confidenceL2 = prefs.getFloat(PREF_CONFIDENCE_L2, DEFAULT_CONFIDENCE),
            confidenceDtw = prefs.getFloat(PREF_CONFIDENCE_DTW, DEFAULT_CONFIDENCE),
            strictSandboxL2 = prefs.getBoolean(PREF_STRICT_SANDBOX_L2, DEFAULT_STRICT_SANDBOX),
            strictSandboxDtw = prefs.getBoolean(PREF_STRICT_SANDBOX_DTW, DEFAULT_STRICT_SANDBOX),
            participateDeepL2 = prefs.getBoolean(PREF_PARTICIPATE_DEEP_L2, DEFAULT_PARTICIPATE_DEEP),
            participateDeepDtw = prefs.getBoolean(PREF_PARTICIPATE_DEEP_DTW, DEFAULT_PARTICIPATE_DEEP),
            deepSearchTrigger = prefs.getString(PREF_DEEP_SEARCH_TRIGGER, DEFAULT_DEEP_SEARCH_TRIGGER) ?: DEFAULT_DEEP_SEARCH_TRIGGER,
            showEngineId = prefs.getBoolean(PREF_SHOW_ENGINE_ID, DEFAULT_SHOW_ENGINE_ID),
            sandboxSize = prefs.getInt(PREF_SANDBOX_SIZE, DEFAULT_SANDBOX_SIZE),
            evictionPolicy = prefs.getString(PREF_EVICTION_POLICY, DEFAULT_EVICTION_POLICY) ?: DEFAULT_EVICTION_POLICY,
        )
    }

    fun saveSettings(context: Context, settings: Settings) {
        val prefs = context.prefs()
        prefs.edit {
            putBoolean(PREF_ENABLE_L2, settings.enableL2)
            putBoolean(PREF_ENABLE_DTW, settings.enableDtw)
            putString(PREF_PRIMARY_ENGINE, settings.primaryEngine)
            putString(PREF_FALLBACK_ENGINE, settings.fallbackEngine)
            putBoolean(PREF_PARALLEL_MODE, settings.parallelMode)
            putString(PREF_SCOPE_L2, settings.scopeL2)
            putString(PREF_SCOPE_DTW, settings.scopeDtw)
            putFloat(PREF_CONFIDENCE_L2, settings.confidenceL2)
            putFloat(PREF_CONFIDENCE_DTW, settings.confidenceDtw)
            putBoolean(PREF_STRICT_SANDBOX_L2, settings.strictSandboxL2)
            putBoolean(PREF_STRICT_SANDBOX_DTW, settings.strictSandboxDtw)
            putBoolean(PREF_PARTICIPATE_DEEP_L2, settings.participateDeepL2)
            putBoolean(PREF_PARTICIPATE_DEEP_DTW, settings.participateDeepDtw)
            putString(PREF_DEEP_SEARCH_TRIGGER, settings.deepSearchTrigger)
            putBoolean(PREF_SHOW_ENGINE_ID, settings.showEngineId)
            putInt(PREF_SANDBOX_SIZE, settings.sandboxSize)
            putString(PREF_EVICTION_POLICY, settings.evictionPolicy)
        }
    }

    // ─── Convenience getters for individual preferences ────────────────────
    fun isL2Enabled(context: Context) = context.prefs().getBoolean(PREF_ENABLE_L2, DEFAULT_ENABLE_L2)
    fun isDtwEnabled(context: Context) = context.prefs().getBoolean(PREF_ENABLE_DTW, DEFAULT_ENABLE_DTW)
    fun getPrimaryEngine(context: Context) = context.prefs().getString(PREF_PRIMARY_ENGINE, DEFAULT_PRIMARY_ENGINE) ?: DEFAULT_PRIMARY_ENGINE
    fun getFallbackEngine(context: Context) = context.prefs().getString(PREF_FALLBACK_ENGINE, DEFAULT_FALLBACK_ENGINE) ?: DEFAULT_FALLBACK_ENGINE
    fun isParallelMode(context: Context) = context.prefs().getBoolean(PREF_PARALLEL_MODE, DEFAULT_PARALLEL_MODE)
    fun getScopeL2(context: Context) = context.prefs().getString(PREF_SCOPE_L2, DEFAULT_SCOPE_L2) ?: DEFAULT_SCOPE_L2
    fun getScopeDtw(context: Context) = context.prefs().getString(PREF_SCOPE_DTW, DEFAULT_SCOPE_DTW) ?: DEFAULT_SCOPE_DTW
    fun getConfidenceL2(context: Context) = context.prefs().getFloat(PREF_CONFIDENCE_L2, DEFAULT_CONFIDENCE)
    fun getConfidenceDtw(context: Context) = context.prefs().getFloat(PREF_CONFIDENCE_DTW, DEFAULT_CONFIDENCE)
    fun isStrictSandboxL2(context: Context) = context.prefs().getBoolean(PREF_STRICT_SANDBOX_L2, DEFAULT_STRICT_SANDBOX)
    fun isStrictSandboxDtw(context: Context) = context.prefs().getBoolean(PREF_STRICT_SANDBOX_DTW, DEFAULT_STRICT_SANDBOX)
    fun isParticipateDeepL2(context: Context) = context.prefs().getBoolean(PREF_PARTICIPATE_DEEP_L2, DEFAULT_PARTICIPATE_DEEP)
    fun isParticipateDeepDtw(context: Context) = context.prefs().getBoolean(PREF_PARTICIPATE_DEEP_DTW, DEFAULT_PARTICIPATE_DEEP)
    fun getDeepSearchTrigger(context: Context) = context.prefs().getString(PREF_DEEP_SEARCH_TRIGGER, DEFAULT_DEEP_SEARCH_TRIGGER) ?: DEFAULT_DEEP_SEARCH_TRIGGER
    fun showEngineId(context: Context) = context.prefs().getBoolean(PREF_SHOW_ENGINE_ID, DEFAULT_SHOW_ENGINE_ID)
    fun getSandboxSize(context: Context) = context.prefs().getInt(PREF_SANDBOX_SIZE, DEFAULT_SANDBOX_SIZE)
    fun getEvictionPolicy(context: Context) = context.prefs().getString(PREF_EVICTION_POLICY, DEFAULT_EVICTION_POLICY) ?: DEFAULT_EVICTION_POLICY

    // ─── MISSING STATIC METHODS THAT SettingsValues.java EXPECTS ──────────
    // These correspond to the getters that were missing in the previous version.
    // They are now added to resolve the Java compilation errors.

    fun getUseSandbox(context: Context): Boolean = isL2Enabled(context) // actually "use sandbox" is L2?
    // In your original code, "use sandbox" likely means use the sandbox engine, which is L2.
    // But the old code had separate settings; we'll assume it's the same as enableL2.
    // However, if you had a separate "use sandbox" setting, we'll map it to enableL2.
    // Since we don't have the old constants, we'll just return isL2Enabled(context).

    fun getUseDtw(context: Context): Boolean = isDtwEnabled(context)

    fun getRestrictToSandbox(context: Context): Boolean = isStrictSandboxL2(context) // or both?
    // The "restrict to sandbox" flag likely means that the primary engine should be restricted to sandbox.
    // We'll map it to strict sandbox for the primary engine.

    fun getSandboxThreshold(context: Context): Float = getConfidenceL2(context)

    fun getProximityRadius(context: Context): Float = 0.035f // default; you can make it a preference later

    fun getAlignmentTolerance(context: Context): Float = 0.025f // default

    fun getNodeFilterEnabled(context: Context): Boolean = false // default

    fun getNodeMatchRatio(context: Context): Float = 0.75f // default

    fun getNodeFilterBeforeScoring(context: Context): Boolean = false

    fun getNodeAngleThreshold(context: Context): Float = 45f

    fun getLearnTappedKnown(context: Context): Boolean = true

    fun getLearnTappedUnknown(context: Context): Boolean = false

    fun getSyncUserDict(context: Context): Boolean = true

    fun getPathsPerWord(context: Context): Int = 3

    fun getToleranceBoost(context: Context): Float = 0.2f

    fun getOffsetCopies(context: Context): Int = 1

    fun getDwellTime(context: Context): Int = 80

    fun getWiggleSensitivity(context: Context): Float = 0.5f

    fun getLoopSensitivity(context: Context): Float = 0.5f

    fun getShowEngineId(context: Context): Boolean = false
}
